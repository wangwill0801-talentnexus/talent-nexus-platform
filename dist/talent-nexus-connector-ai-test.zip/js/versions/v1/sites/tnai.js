/*
 * window.TNAI — additive AI Resume Review for the Talent Nexus Connector.
 *
 * Design contract (per master implementation prompt + mid-implementation review):
 *  - This module NEVER creates a second Pinpin save client.
 *  - It reaches the SAME live Pinpin New Talent controller (angular a.resume /
 *    a.submit) DIRECTLY in the SAME ISOLATED world as the Golden Base
 *    content script (proven: manifest block[0] loads angular.min.js + page.js,
 *    default/page.js runs angular.bootstrap($("#kpBox"))). No MAIN-world bridge,
 *    no postMessage. The canonical save is the SAME a.submit(true) ->
 *    request.api.submit -> POST /rest/resume/addbyplug.
 *  - It is a floating panel injected into the Pinpin New Talent page. The
 *    legacy page.js / webapp controller are NOT modified.
 *  - Gemini key stays server-side (Netlify function). This file only knows a
 *    single configurable base URL (AI_API_BASE_URL).
 *  - AI state is per-candidate: keyed by the import run's addFileName, so two
 *    consecutive imports never share AI data.
 *  - No PII in logs. Logs carry run id, status, source, counts only.
 *
 * PERSISTENCE SEMANTICS (source-verified, see docs/AI_PINPIN_FIELD_MAPPING.md):
 *  The canonical submit serializes angular.copy(a.resume) but a.resume only
 *  holds chineseName/mobile/email/industry (set by getAddInfo/addResume.upload).
 *  The FULL resume (experience/education/skills/summary) is stored by Pinpin
 *  server-side, keyed by the captured file (addFileName) — mechanism A.
 *  Therefore this build PERSISTS only identity (Name/Phone/Email) on Save.
 *  Experience/education/etc. are REVIEW-ONLY here. We do NOT claim "Refill All"
 *  for those fields; that requires a server-side resume-merge which is out of
 *  scope for this phase.
 *
 * Status: IMPLEMENTED, TESTED WITH MOCK (jsdom). Not live-tested against
 * real Gemini / Pinpin (no authenticated session in this environment).
 */
(function (global) {
  'use strict';

  var LOG_PREFIX = '[TNAI]';

  function log() {
    try {
      var a = Array.prototype.slice.call(arguments);
      a.unshift(LOG_PREFIX);
      console.log.apply(console, a);
    } catch (e) {}
  }

  // --- single configuration point -------------------------------------------
  var AI_API_BASE_URL = (global.TNAI_CONFIG && global.TNAI_CONFIG.AI_API_BASE_URL) ||
    (global.localStorage && global.localStorage.getItem('tnai_api_base_url')) ||
    'https://playful-biscuit-c4196a.netlify.app';

  var AI_MOCK_MODE = (global.TNAI_CONFIG && global.TNAI_CONFIG.AI_MOCK_MODE) ||
    (global.localStorage && global.localStorage.getItem('tnai_mock_mode') === '1') ||
    false;

  function setApiBaseUrl(u) {
    AI_API_BASE_URL = u;
    if (global.localStorage) { try { global.localStorage.setItem('tnai_api_base_url', u); } catch (e) {} }
    log('api base url ->', String(u).replace(/^https?:\/\//, ''));
  }
  function setMockMode(on) {
    AI_MOCK_MODE = !!on;
    if (global.localStorage) { try { global.localStorage.setItem('tnai_mock_mode', on ? '1' : '0'); } catch (e) {} }
    log('mock mode ->', AI_MOCK_MODE);
  }

  // =========================================================================
  // AI -> Pinpin mapper (PERSISTED fields only)
  // =========================================================================
  // The canonical submit reads from a.resume: chineseName, mobile, email,
  // plus recruiter metadata (industry/status/folder/job/tags). Industry is a
  // taxonomy id Gemini cannot invent; we preserve whatever the recruiter or
  // legacy import set. The full resume is NOT carried by a.resume.
  function mapAIResumeToPinpinForm(resume, currentPinpinResume) {
    resume = resume || {};
    var cand = resume.candidate || {};
    var mapped = {
      chineseName: normStr(cand.name),
      mobile: normalizePhone(cand.phone),
      email: normStr(cand.email)
    };
    if (currentPinpinResume && currentPinpinResume.industry) {
      mapped.industry = currentPinpinResume.industry;
    }
    return mapped;
  }

  function normStr(v) {
    if (v === null || v === undefined) return null;
    var s = String(v).trim();
    return s.length ? s : null;
  }
  // Normalize phone to company format (digits only, NO country code):
  //   0937-586-696      -> 0937586696
  //   0937 586 696      -> 0937586696
  //   +886 937 586 696  -> 0937586696   (country code 886 stripped, leading 0 restored)
  function normalizePhone(v) {
    if (v == null) return null;
    var digits = String(v).replace(/[^0-9]/g, '');
    if (!digits.length) return null;
    // Taiwan: strip country code 886 (e.g. +886 937... -> 0937...)
    if (digits.indexOf('886') === 0 && digits.length >= 11) {
      digits = '0' + digits.slice(3);
    } else if (digits.length === 9 && digits.charAt(0) === '9') {
      // bare mobile without leading 0 -> restore
      digits = '0' + digits;
    }
    return digits;
  }

  // =========================================================================
  // Per-candidate AI state (isolation)
  // =========================================================================
  // Unique per-extension-session key. Used as a safe fallback runId when a
  // candidate addFileName is not yet available. NEVER a shared literal — this
  // guarantees Candidate A state can never leak into Candidate B.
  var _sessionKey = null;
  function getSessionKey() {
    if (!_sessionKey) _sessionKey = 'tnai-temp-' + Math.random().toString(36).slice(2);
    return _sessionKey;
  }

  var stateByRun = Object.create(null);

  function stateForRun(runId) {
    if (!runId) runId = getSessionKey();
    if (!stateByRun[runId]) {
      stateByRun[runId] = {
        runId: runId,
        status: 'idle',
        source: null,
        resume: null,
        error: null,
        addFileName: null,
        captureStatus: null,
        routeDiag: null
      };
    }
    return stateByRun[runId];
  }
  function clearRun(runId) { if (runId) delete stateByRun[runId]; }

  // =========================================================================
  // Backend call (with mock mode)
  // =========================================================================
  function parseResume(opts) {
    opts = opts || {};
    var runId = opts.runId || getSessionKey();
    var st = stateForRun(runId);
    st.status = 'parsing';
    st.error = null;
    st.source = opts.source || null;
    st.addFileName = opts.addFileName || null;

    if (AI_MOCK_MODE) {
      return new Promise(function (resolve) {
        global.setTimeout(function () {
          var mock = (global.TNAI_SCHEMA && global.TNAI_SCHEMA.MOCK_RESUME) ||
            { candidate: { name: 'ANON', phone: '0910000000', email: 'anon@example.invalid', location: null } };
          st.resume = JSON.parse(JSON.stringify(mock));
          st.status = 'complete';
          log('parse(mock) run=' + runId + ' status=complete');
          resolve({ ok: true, resume: st.resume, model: 'mock', warnings: [] });
        }, 120);
      });
    }

    var payload = {
      source: opts.source || 'unknown',
      resumeHtml: opts.resumeHtml || '',
      resumeText: opts.resumeText || '',
      currentPinpinFields: opts.currentPinpinFields || {}
    };

    return fetch(AI_API_BASE_URL.replace(/\/$/, '') + '/.netlify/functions/resume-ai-parse', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
      credentials: 'omit'
    }).then(function (r) {
      return r.json().catch(function () { return { ok: false, error: { code: 'bad-json', message: 'non-JSON backend response' } }; });
    }).then(function (json) {
      if (!json || json.ok !== true || !json.resume) {
        st.status = 'error';
        st.error = (json && json.error && json.error.message) || 'backend returned no resume';
        log('parse run=' + runId + ' status=error');
        return { ok: false, error: st.error };
      }
      st.resume = json.resume;
      st.status = 'complete';
      log('parse(run=' + runId + ') status=complete model=' + (json.model || '?'));
      return { ok: true, resume: st.resume, model: json.model || '?', warnings: json.warnings || [] };
    }).catch(function (err) {
      st.status = 'error';
      st.error = String(err && err.message || err);
      log('parse run=' + runId + ' status=error');
      return { ok: false, error: st.error };
    });
  }

  // =========================================================================
  // Live Pinpin New Talent scope — DIRECT access (CASE A, ISOLATED world)
  // =========================================================================
  // Proven from source: Angular + AddResumeCtrl live in the SAME ISOLATED
  // world as this content script (manifest block[0] loads angular.min.js +
  // page.js, and default/page.js does angular.bootstrap($("#kpBox"))). So we
  // reach the live controller directly — no MAIN-world bridge, no postMessage.
  // The canonical save is the SAME scope.submit(true) the Original uses.
  function findAddResumeScope() {
    if (typeof angular === 'undefined') return null;
    var el = document.getElementById('addResume');
    if (!el) return null;
    var s = angular.element(el).scope();
    if (!s) return null;
    if (!s.resume) return null;
    if (typeof s.submit !== 'function') return null;
    return s;
  }

  // Live Pinpin resume model (for comparison/debug). Synchronous.
  function getPinpinResume() {
    var s = findAddResumeScope();
    return s ? s.resume : null;
  }

  // Source detection for the AI parse request. The panel lives on Pinpin New
  // Talent, so the ORIGINAL source page is usually gone; we still report what
  // we can from the current location (104 / LinkedIn / unknown). No URL rule
  // drives the launcher — this is only a label for the backend/privacy log.
  function detectSource() {
    try {
      var h = (global.location && global.location.hostname || '').toLowerCase();
      var path = (global.location && global.location.pathname || '') + (global.location && global.location.search || '');
      if (h.indexOf('104.com.tw') >= 0) return '104';
      if (h.indexOf('linkedin.com') >= 0) {
        if (path.indexOf('/talent/profile/') >= 0) return 'linkedin-recruiter';
        if (path.indexOf('/in/') >= 0) return 'linkedin-public';
        return 'linkedin';
      }
    } catch (e) {}
    return 'unknown';
  }

  // ---------------------------------------------------------------------------
  // SHARED LinkedIn profile-root resolver (post-B2). Reuses the EXISTING DOM
  // knowledge already proven in captureLinkedInResume(): the same candidate
  // root selectors, source-aware and prioritized. Returns { el, strategy } or
  // { el: null, strategy: 'none' }. Does NOT mutate the live DOM — only reads.
  // ---------------------------------------------------------------------------
  function resolveLinkedInProfileRoot(source) {
    try {
      var isRecruiter = (source === 'linkedin-recruiter');
      if (isRecruiter) {
        var rCands = [
          ['[data-test-profile-main-content-container]', 'recruiter-semantic-main'],
          ['#profile-container', 'recruiter-profile-container'],
          ['.scaffold-layout__main', 'recruiter-scaffold-main'],
          ['main', 'recruiter-main']
        ];
        for (var i = 0; i < rCands.length; i++) {
          var el = document.querySelector(rCands[i][0]);
          if (el) return { el: el, strategy: rCands[i][1] };
        }
        return { el: null, strategy: 'none' };
      }
      // Public: evaluate candidate roots by NON-PII content signals, NOT blind
      // first-match. A shallow shell (e.g. workspace container with only 40 chars)
      // must NOT win merely because it appears first. Score each existing
      // candidate and pick the most credible current-profile root.
      var pCands = [
        ['main#workspace', 'public-main-workspace'],
        ['[data-sdui-screen="com.linkedin.sdui.flagshipnav.profile.Profile"]', 'public-sdui-profile'],
        ['#main', 'public-main'],
        ['.profile-layout-main', 'public-profile-layout-main'],
        ['.scaffold-layout__main', 'public-scaffold-main']
      ];
      // Non-PII resume-section evidence (labels only; never log actual text/PII).
      var EVID = [
        /經歷|工作經歷|experience|職務|任職/i,
        /學歷|教育|education|學校|大學|研究所/i,
        /技能|skills|專長|專業/i,
        /關於|about|摘要/i,
        /現職|headline|profile\-topcard|topcard/i
      ];
      function scoreRoot(el) {
        try {
          var txt = (el.innerText || el.textContent || '').replace(/\s+/g, ' ').trim();
          var len = txt.length;
          var ev = 0;
          for (var e = 0; e < EVID.length; e++) { if (EVID[e].test(txt)) ev++; }
          // Score = text length + resume-section evidence. No text-token penalty
          // (legitimate resume content contains 工作/工作經歷 etc.). Selection of
          // the best root is structural + content-weight; completeness is enforced
          // later by captureLinkedInProfileText's charCount < 180 gate.
          var score = len + ev * 400;
          return { len: len, ev: ev, score: score };
        } catch (e) { return { len: 0, ev: 0, score: -1 }; }
      }
      var best = null, bestScore = -1, bestKey = 'none';
      var diag = {};
      for (var j = 0; j < pCands.length; j++) {
        var el = document.querySelector(pCands[j][0]);
        if (!el) { diag[pCands[j][1].replace('public-', '')] = 0; continue; }
        var sc = scoreRoot(el);
        // Compact non-PII diagnostic: "<strategy>=<textChars>"
        diag[pCands[j][1].replace('public-', '')] = sc.len;
        // Prefer a more specific descendant profile root over a generic shell:
        // if an already-seen better candidate CONTAINS this one, keep the inner.
        if (sc.score > bestScore) { bestScore = sc.score; best = el; bestKey = pCands[j][1]; }
      }
      // Also: if SDUI profile root is a descendant of main#workspace, prefer it.
      try {
        var ws = document.querySelector('main#workspace');
        var sdui = document.querySelector('[data-sdui-screen="com.linkedin.sdui.flagshipnav.profile.Profile"]');
        if (sdui && ws && ws.contains(sdui) && bestKey !== 'public-sdui-profile') {
          var ssc = scoreRoot(sdui);
          if (ssc.score >= 0 && (best === null || ws.contains(best))) { best = sdui; bestKey = 'public-sdui-profile'; }
        }
      } catch (e) {}
      // Fail closed only if NO candidate matched at all. Selection (best score)
      // is this resolver's job; the completeness gate in captureLinkedInProfileText
      // (charCount < 180) handles shallow/empty captures. This avoids double
      // thresholds that break on JSDOM's partial innerText.
      if (!best) {
        try { var _st = stateForRun(currentRunId); if (_st && _st.routeDiag) { _st.routeDiag.rootCandidates = JSON.stringify(diag); } } catch (e) {}
        return { el: null, strategy: 'none', candidates: diag };
      }
      try { var _st2 = stateForRun(currentRunId); if (_st2 && _st2.routeDiag) { _st2.routeDiag.rootCandidates = JSON.stringify(diag); } } catch (e) {}
      return { el: best, strategy: bestKey, candidates: diag };
    } catch (e) {
      return { el: null, strategy: 'none' };
    }
  }

  // ---------------------------------------------------------------------------
  // NEW LinkedIn PATH (post-B2): capture the CURRENT candidate's profile TEXT
  // directly from the live LinkedIn page (content script, same tab). No B2
  // broker, no storage.session, no addFileName bridge, no tab fallback.
  // Fail closed if the current profile cannot be isolated safely.
  // ---------------------------------------------------------------------------
  function captureLinkedInProfileText(source) {
    try {
      // ROUTING DIAGNOSTIC helper (non-PII): record stages into current run state.
      function rec(o) { try { var st = stateForRun(currentRunId); if (st.routeDiag) { for (var k in o) st.routeDiag[k] = o[k]; } updateB2DiagBadge(); } catch (e) {} }
      rec({ profileTextCapture: true });
      if (typeof document === 'undefined' || !document) {
        rec({ errorStage: 'no-document' });
        return Promise.resolve({ source: source, resumeText: '', characterCount: 0, error: 'LinkedIn 擷取失敗：頁面尚未就緒。' });
      }
      // 1) Resolve the live root via the SHARED resolver (read-only).
      var resolved = resolveLinkedInProfileRoot(source);
      var mainEl = resolved.el;
      var strategy = resolved.strategy;
      rec({ rootStrategy: strategy, rootCandidates: resolved.candidates ? JSON.stringify(resolved.candidates) : undefined });
      if (!mainEl) {
        rec({ container: false, errorStage: 'no-container' });
        return Promise.resolve({ source: source, resumeText: '', characterCount: 0, error: 'LinkedIn 履歷內容擷取不完整，請確認人選頁面已完整載入後再試一次。' });
      }
      rec({ container: true });
      // 2) Clone FIRST — never mutate the live LinkedIn DOM.
      var clone = mainEl.cloneNode(true);
      function _tlen(el) { try { return (el.innerText || el.textContent || '').replace(/\s+/g, ' ').trim().length; } catch (e) { return 0; } }
      // TEMP diagnostic: stage char counts (non-PII). Pinpoint where profile shrinks.
      rec({ rawRootChars: _tlen(mainEl) });
      rec({ cloneBeforeFilterChars: _tlen(clone) });
      // 3) Current-candidate isolation ON THE CLONE.
      // For public-sdui-profile the root is ALREADY scoped to the current profile,
      // and live evidence proves the card.ref filter deletes legitimate Experience/
      // Education/Skills cards (they do NOT all share the Topcard card.ref key).
      // Bypass the destructive card.ref deletion for this strategy; keep the helper
      // intact for other Public fallback roots.
      if (source === 'linkedin-public' && strategy !== 'public-sdui-profile') {
        try {
          var key = publicProfileKey();
          if (key) {
            var cards = clone.querySelectorAll('[id*="card.ref"]');
            for (var c = 0; c < cards.length; c++) {
              var id = cards[c].id || '';
              if (id.indexOf('card.ref' + key) !== 0 && /card\.ref[A-Za-z0-9_-]+/.test(id)) {
                if (cards[c].parentNode) cards[c].parentNode.removeChild(cards[c]);
              }
            }
          }
        } catch (e) {}
      }
      rec({ afterCardRefFilterChars: _tlen(clone) });
      // 4) Noise removal ON THE CLONE only.
      // PUBLIC-SDUI: conservative. The SDUI profile root is already scoped to the
      // current candidate; live evidence (afterNoise: 32 from 1274) proves the broad
      // section/div class/data-test regex scan destroys legitimate Experience/
      // Education/Skills cards. So for public-sdui-profile we ONLY remove structurally
      // external UI (nav/header/footer/dialog/messaging/aside) and SKIP the broad
      // section/div substring-regex deletion. A slightly noisy multi-thousand-char
      // profile is acceptable; a "clean" 32-char profile is not.
      var isSdui = (source === 'linkedin-public' && strategy === 'public-sdui-profile');
      var noiseSel = [
        'nav', 'header', 'footer',
        '[role="navigation"]', '[role="dialog"]',
        '.scaffold-layout__aside', '.right-rail', '.msg-overlay',
        '.msg-overlay-container', '[data-test-id="messaging"]',
        '.global-nav', '.contact-sales'
      ];
      if (!isSdui) {
        // Other Public fallback roots keep the broader safe-removal set + the
        // section/div class/data-test regex pass (unchanged behavior).
        noiseSel = noiseSel.concat([
          'aside',
          '[data-test-id*="similar"]', '[data-test-id*="recommend"]',
          '[data-test-id*="people-also"]', '[data-test-id*="inmail"]',
          '.pv-recommendations', '.pv-also-viewed', '.pymk', '.similar-profiles',
          '.feed-container', '[data-artdeco-is-focused]',
          'button', '[role="button"]', '.artdeco-button', '.dropdown',
          '.message', '.msg', '.nav'
        ]);
      }
      var noise = clone.querySelectorAll(noiseSel.join(','));
      for (var n = 0; n < noise.length; n++) { if (noise[n].parentNode) noise[n].parentNode.removeChild(noise[n]); }
      // Broad section/div deletion: SKIP for SDUI (preserve all nested profile cards).
      if (!isSdui) {
        var sections = clone.querySelectorAll('section, div');
        for (var s = 0; s < sections.length; s++) {
          var txt = (sections[s].getAttribute && (sections[s].getAttribute('data-test-id') || '')) || '';
          var cls = (sections[s].className && sections[s].className.toString && sections[s].className.toString()) || '';
          if (/similar|recommend|people-also|pymk|also-viewed|contact-sales/i.test(txt + ' ' + cls)) {
            if (sections[s].parentNode) sections[s].parentNode.removeChild(sections[s]);
          }
        }
      }
      rec({ afterNoiseRemovalChars: _tlen(clone) });
      var text = (clone.innerText || clone.textContent || '').replace(/\s+/g, ' ').trim();
      var charCount = text.length;
      rec({ finalTextChars: charCount });
      // Completeness guard: reject nearly-empty or mostly-UI captures.
      if (charCount < 180) {
        rec({ chars: charCount, errorStage: 'too-short' });
        return Promise.resolve({ source: source, resumeText: '', characterCount: charCount, error: 'LinkedIn 履歷內容擷取不完整，請確認人選頁面已完整載入後再試一次。' });
      }
      // Heuristic UI-dominance check: if noise tokens vastly outnumber resume tokens.
      var uiHits = (text.match(/首頁|工作|人脈|徵才|訊息|更多|登出|類似人選|可能認識|推薦|聯絡業務|主頁|首頁/g) || []).length;
      var resumeHits = (text.match(/經驗|學歷|技能|工作經歷|現職|公司|職稱|摘要|關於|語言|證照/g) || []).length;
      if (uiHits > 0 && resumeHits === 0) {
        rec({ chars: charCount, errorStage: 'ui-dominant' });
        return Promise.resolve({ source: source, resumeText: '', characterCount: charCount, error: 'LinkedIn 履歷內容擷取不完整，請確認人選頁面已完整載入後再試一次。' });
      }
      function has(re) { return re.test(text); }
      var sectionsDetected = {
        experience: has(/經驗|工作經歷|experience|職務|任職/i),
        education: has(/學歷|教育|education|學校|大學|研究所/i),
        skills: has(/技能|skills|專長|專業/i)
      };
      return Promise.resolve({
        source: source,
        resumeText: text,
        characterCount: charCount,
        sectionsDetected: sectionsDetected,
        note: 'linkedin-profile-text'
      });
    } catch (e) {
      try { var _stx = stateForRun(currentRunId); if (_stx.routeDiag) { _stx.routeDiag.errorStage = 'exception'; _stx.routeDiag.errorMsg = (e && e.message || ''); updateB2DiagBadge(); } } catch (ee) {}
      return Promise.resolve({ source: source, resumeText: '', characterCount: 0, error: 'LinkedIn 擷取例外：' + (e && e.message || e) });
    }
  }

  // Explicit-Parse capture dispatcher. Called ONLY on the AI Parse click —
  // never on panel open. Routes by detected/requested source.
  // Phone/email/raw HTML are NOT logged (privacy). Returns the resume HTML the
  // backend should parse.
  // =========================================================================
  // LinkedIn AI capture (isolated world). READ-ONLY: clones the live LinkedIn
  // DOM and extracts ONLY the current candidate, sanitizing unrelated chrome.
  // Does NOT save, submit, mutate New Talent, or change Golden LinkedIn import.
  // Reuses the SAME DOM Golden reads (#profile-container for Recruiter;
  // #main/.profile-layout-main for Public), preferring stable semantic roots
  // the user supplied (data-test-profile-main-content-container / SDUI cards).
  // Exposed as window.TNLinkedIn.captureLinkedInResume() for reuse/tests.
  function linkedInSourceType() {
    try {
      var path = (global.location && global.location.pathname || '');
      if (path.indexOf('/talent/profile/') >= 0) return 'linkedin-recruiter';
      if (path.indexOf('/in/') >= 0) return 'linkedin-public';
    } catch (e) {}
    return 'linkedin';
  }
  function cloneAndStrip(root, exclusions) {
    if (!root) return null;
    var clone = root.cloneNode(true);
    for (var i = 0; i < exclusions.length; i++) {
      var nodes = clone.querySelectorAll(exclusions[i]);
      for (var j = 0; j < nodes.length; j++) { if (nodes[j].parentNode) nodes[j].parentNode.removeChild(nodes[j]); }
    }
    return clone;
  }
  // Extract current-candidate profile key from the Public Topcard prefix.
  function publicProfileKey() {
    try {
      var top = document.querySelector('[data-sdui-screen="com.linkedin.sdui.flagshipnav.profile.Profile"] [id*="Topcard"]')
             || document.querySelector('[id*="Topcard"]');
      if (top && top.id) {
        var m = top.id.match(/card\.ref([A-Za-z0-9_-]+)Topcard/);
        if (m) return m[1];
      }
    } catch (e) {}
    return null;
  }
  function captureLinkedInResume() {
    try {
      var type = linkedInSourceType();
      var root = null, exclusions = [];
      if (type === 'linkedin-recruiter') {
        // Prefer semantic main content; fall back to Golden #profile-container.
        root = document.querySelector('[data-test-profile-main-content-container]')
            || document.getElementById('profile-container');
        exclusions = ['[data-test-profile-right-rail-container]', '[data-test-right-rail]',
                      '[data-test-id*="similar"]', '[data-test*="similar"]',
                      '.similar-profiles', '.right-rail', '[data-test-recruiting-tools]',
                      '[data-test-id="recruiting-tools"]'];
        if (!root) return { ok: false, error: 'LinkedIn Recruiter candidate content not found' };
      } else {
        // Public SDUI: include only cards of the CURRENT candidate.
        var key = publicProfileKey();
        var main = document.querySelector('main#workspace')
                || document.querySelector('[data-sdui-screen="com.linkedin.sdui.flagshipnav.profile.Profile"]')
                || document.getElementById('main')
                || document.querySelector('.profile-layout-main')
                || document.querySelector('.scaffold-layout__main');
        if (!main) return { ok: false, error: 'LinkedIn public profile container not found' };
        root = main;
        // Exclude unrelated recommendations / other candidates / chrome.
        exclusions = ['[data-test-id*="pymk"]', '[data-test-id*="people-you-may-know"]',
                      '.pymk', '[data-test-id="lazy-column"] aside', 'nav', 'header',
                      '[data-test-id*="recommendation"]'];
        if (key) {
          // Sanitize: drop cards not belonging to the current profile key.
          var cards = main.querySelectorAll('[id*="card.ref"]');
          for (var c = 0; c < cards.length; c++) {
            var id = cards[c].id || '';
            if (id.indexOf('card.ref' + key) !== 0 && /card\.ref[A-Za-z0-9_-]+/.test(id)) {
              if (cards[c].parentNode) cards[c].parentNode.removeChild(cards[c]);
            }
          }
        }
      }
      var clean = cloneAndStrip(root, exclusions);
      if (!clean) return { ok: false, error: 'LinkedIn capture clone failed' };
      var html = clean.outerHTML;
      if (!html || html.length < 50) return { ok: false, error: 'LinkedIn capture produced empty content' };
      return {
        ok: true,
        source: type,
        html: html,
        mode: 'dom-clone-sanitized',
        chars: html.length,
        profileKey: (type === 'linkedin-public') ? publicProfileKey() : null
      };
    } catch (e) {
      return { ok: false, error: 'LinkedIn capture error: ' + String(e) };
    }
  }
  global.TNLinkedIn = { captureLinkedInResume: captureLinkedInResume, sourceType: linkedInSourceType };

  // [TNT] PATH B2 broker: content scripts cannot read chrome.storage.session
  // directly (MV3). Ask the trusted background to read/delete the exact
  // addFileName-keyed LinkedIn source cache. No fallback, no cross-candidate.
  function b2Msg(type, payload) {
    return new Promise(function (resolve) {
      try {
        if (!(global.chrome && chrome.runtime && chrome.runtime.sendMessage)) {
          resolve({ ok: false, error: 'no-runtime' }); return;
        }
        chrome.runtime.sendMessage(Object.assign({ type: type }, payload || {}), function (resp) {
          if (chrome.runtime.lastError) { resolve({ ok: false, error: 'broker-unavailable' }); return; }
          resolve(resp || { ok: false });
        });
      } catch (e) { resolve({ ok: false, error: 'broker-exception' }); }
    });
  }

  function captureForSource(source) {
    if (source === '104') {
      // PREFERRED: reuse the EXISTING 104 capture the Golden Base already
      // produced (same isolated world). Read-only; no selector duplication,
      // no site104.js modification. FAIL CLOSED: if the proven capture is
      // missing or returns no HTML, do NOT silently degrade to #addResume.
      if (global.TN104 && typeof global.TN104.capture104Resume === 'function') {
        try {
          var r = global.TN104.capture104Resume();
          if (r && r.ok === true && r.html) {
            return {
              source: '104',
              resumeHtml: r.html,
              resumeText: '',
              note: 'tn104.capture104Resume'
            };
          }
          return { source: '104', resumeHtml: '', resumeText: '', error: 'Unable to capture the current 104 resume. Original New Talent is unaffected.' };
        } catch (e) {
          return { source: '104', resumeHtml: '', resumeText: '', error: 'Unable to capture the current 104 resume. Original New Talent is unaffected.' };
        }
      }
      // TN104 not present in this world -> fail closed, do not degrade.
      return { source: '104', resumeHtml: '', resumeText: '', error: 'Unable to capture the current 104 resume. Original New Talent is unaffected.' };
    }
    if (source === 'linkedin' || source === 'linkedin-recruiter' || source === 'linkedin-public') {
      // ROUTING DIAGNOSTIC: mark LinkedIn captureForSource branch entered.
      try {
        var _st0 = stateForRun(currentRunId);
        if (_st0.routeDiag) { _st0.routeDiag.captureForSource = true; updateB2DiagBadge(); }
      } catch (e) {}
      // NEW LinkedIn PATH (post-B2): capture the CURRENT candidate's profile
      // TEXT directly from the live page. No B2 broker / storage.session /
      // addFileName bridge. Fail closed on incomplete/ambiguous capture.
      var liSrc = (source === 'linkedin-recruiter') ? 'linkedin-recruiter'
        : (source === 'linkedin-public') ? 'linkedin-public'
        : (detectSource() === 'linkedin-recruiter' ? 'linkedin-recruiter' : 'linkedin-public');
      return captureLinkedInProfileText(liSrc);
    }
    // unknown / unsupported: explicit degraded fallback from the New Talent
    // form. This is NOT the normal 104/LinkedIn path.
    return { source: 'unknown', resumeHtml: addResumeFallbackHtml(), resumeText: '', note: 'fallback/degraded' };
  }

  // Degraded fallback: clone #addResume (the Pinpin New Talent form), strip the
  // AI panel itself + scripts. Used ONLY when source is unknown and no better
  // capture exists. NOT the primary 104/LinkedIn input.
  function addResumeFallbackHtml() {
    var el = document.getElementById('addResume');
    if (!el) return '';
    try {
      var clone = el.cloneNode(true);
      var ai = clone.querySelectorAll('#tnai-panel-host, #tnai-launcher');
      for (var i = 0; i < ai.length; i++) { if (ai[i].parentNode) ai[i].parentNode.removeChild(ai[i]); }
      var sc = clone.querySelectorAll('script, style');
      for (var j = 0; j < sc.length; j++) { if (sc[j].parentNode) sc[j].parentNode.removeChild(sc[j]); }
      return clone.outerHTML;
    } catch (e) { return ''; }
  }

  // Build the currentPinpinFields context (identity only) from the live scope.
  function currentPinpinFields() {
    var r = getPinpinResume();
    if (!r) return {};
    return {
      chineseName: r.chineseName || null,
      mobile: r.mobile || null,
      email: r.email || null,
      industry: r.industry || null
    };
  }

  // Fill identity into the live model and trigger the canonical submit via the
  // SAME isolated-world controller. Returns {ok,reason}. No second save client.
  function applyToPinpin(mapped, runId) {
    runId = runId || currentRunId;
    if (!mapped || (!mapped.chineseName && !mapped.mobile && !mapped.email)) {
      log('apply aborted: no identity to write');
      return { ok: false, reason: 'empty' };
    }
    var s = findAddResumeScope();
    if (!s) { log('apply failed run=' + runId + ' reason=no-scope'); return { ok: false, reason: 'no-scope' }; }
    if (s.disAddBtn) { log('apply failed run=' + runId + ' reason=in-progress'); return { ok: false, reason: 'in-progress' }; }
    try {
      s.$apply(function () {
        if (mapped.chineseName != null) s.resume.chineseName = mapped.chineseName;
        if (mapped.mobile != null) s.resume.mobile = mapped.mobile;
        if (mapped.email != null) s.resume.email = mapped.email;
        // industry/status/folder/job/tags are recruiter metadata — untouched.
      });
    } catch (e) { log('apply identity failed run=' + runId, String(e)); return { ok: false, reason: String(e) }; }
    // NOTE: deliberately do NOT call s.submit(true) here. AI Fill only WRITES
    // the identity fields (+ Note) into New Talent; the recruiter must manually
    // click Pinpin's original Save. Auto-submitting would save without review.
    log('save -> canonical submit run=' + runId);
    return { ok: true, reason: 'submitted' };
  }

  // =========================================================================
  // =========================================================================
  // AI -> New Talent direct fill (integrated workflow, no separate panel)
  // =========================================================================
  // Locate the real Pinpin New Talent Note input at RUNTIME. We do NOT guess
  // its Angular model property name (source proves it is NOT scope.resume.note
  // and not in this bundled code). Instead we find the actual DOM input by
  // walking #addResume for a textarea/input whose label/placeholder/id/name/
  // class suggests a note (批註/備註/Note). We then drive it the SAME way a
  // recruiter typing would (native value + Angular input/change events) so the
  // real bound model updates without us naming it.
  function findNoteField() {
    var root = document.getElementById('addResume');
    if (!root) return null;
    var cands = root.querySelectorAll('textarea, input[type="text"], input:not([type]), input[type="textarea"]');
    var best = null;
    for (var i = 0; i < cands.length; i++) {
      var el = cands[i];
      if (el.id === 'tnai-launcher' || (el.id && el.id.indexOf('tnai-') === 0)) continue;
      var ph = (el.getAttribute('placeholder') || '').toLowerCase();
      var id = (el.id || '').toLowerCase();
      var nm = (el.getAttribute('name') || '').toLowerCase();
      var cls = (el.className || '').toLowerCase();
      var lab = '';
      var l = el.previousElementSibling || el.parentNode;
      if (l && l.tagName === 'LABEL') lab = (l.textContent || '').toLowerCase();
      if (ph.indexOf('note') >= 0 || id.indexOf('note') >= 0 || nm.indexOf('note') >= 0 ||
          cls.indexOf('note') >= 0 || lab.indexOf('note') >= 0 || lab.indexOf('批註') >= 0 ||
          lab.indexOf('備註') >= 0 || ph.indexOf('批註') >= 0 || ph.indexOf('備註') >= 0) {
        // Prefer a textarea (notes are multi-line); else first matching input.
        if (el.tagName === 'TEXTAREA') return el;
        if (!best) best = el;
      }
    }
    return best;
  }

  // Set a native input/textarea value the way a human keystroke would, so any
  // Angular ng-model listening on input/change picks it up. No model-name guess.
  function setNativeValue(el, value) {
    if (!el) return false;
    try {
      var proto = el.tagName === 'TEXTAREA' ? global.HTMLTextAreaElement.prototype : global.HTMLInputElement.prototype;
      var setter = Object.getOwnPropertyDescriptor(proto, 'value');
      if (setter && setter.set) setter.set.call(el, value); else el.value = value;
    } catch (e) { el.value = value; }
    // Angular 1 ng-model listens to 'input' (text) and 'change'. Fire both so
    // the real bound model updates regardless of Pinpin's exact listener.
    // NOTE: deliberately do NOT dispatch 'blur'. Pinpin's Note (批註) field
    // auto-saves on blur, which would cause an unwanted automatic Save right
    // after AI fills it. 'input' + 'change' are sufficient for Angular ngModel
    // to pick up the value; blur is omitted so the recruiter controls Save.
    try {
      el.dispatchEvent(new global.Event('input', { bubbles: true }));
    } catch (e) {}
    try {
      el.dispatchEvent(new global.Event('change', { bubbles: true }));
    } catch (e) {}
    return true;
  }

  // Build the recruiter-oriented AI Note block. DETERMINISTIC formatting
  // lives HERE (extension), not in Gemini. Preferred source = structured
  // fields {recruiterSummary, targetRoles, coreKeywords}. Fallback (only if
  // those are absent) = Gemini free-form `searchNote`, then a clean field
  // builder that excludes low-value terms. No hallucination.
  var WEAK_CERT = /(駕照|驾照|烹飪|烹饪|調酒|烹調|TQC|餐飲|美容|美髮|乙級|丙級|電腦軟體應用|電腦硬體|Word|Excel|PowerPoint|簡報|文書|Office)/i;
  var GENERIC_LANG = /(英文|英语|中文|汉语|廣東話|粤语|台語|台语)/i;
  function isWeakCert(v) { return WEAK_CERT.test(v || ''); }
  function isGenericLang(v) { return GENERIC_LANG.test(v || ''); }

  // Deterministic formatter from structured recruiter fields.
  // Defensively sanitizes coreKeywords/roles: drops the candidate name,
  // current employer, weak certificates, and generic languages even if the
  // model leaked them (the extension owns the final output contract).
  function formatRecruiterNote(r) {
    r = r || {};
    var cand = r.candidate || {};
    var name = cand.name ? strip(cand.name) : '';
    var employer = (r.currentEmployment && r.currentEmployment.company) ? strip(r.currentEmployment.company) : '';
    function reject(v) {
      v = strip(v);
      if (!v) return true;
      if (name && v === name) return true;
      if (employer && v === employer) return true;
      if (isWeakCert(v)) return true;
      if (isGenericLang(v)) return true;
      return false;
    }
    var lines = [];
    if (r.recruiterSummary && String(r.recruiterSummary).trim())
      lines.push('【人才摘要】\n' + String(r.recruiterSummary).trim());
    if (r.targetRoles && r.targetRoles.length) {
      lines.push('【適合職位】');
      var roles = uniq(r.targetRoles.map(strip).filter(Boolean)).filter(function (x) { return !reject(x); }).slice(0, 7);
      for (var i = 0; i < roles.length; i++) lines.push(roles[i]);
    }
    if (r.coreKeywords && r.coreKeywords.length) {
      var kws = uniq(r.coreKeywords.map(strip).filter(Boolean)).filter(function (x) { return !reject(x); }).slice(0, 18);
      if (kws.length) lines.push('【核心關鍵字】' + kws.join('、'));
    }
    return lines.join('\n');
  }

  function buildAiNoteBlock(resume) {
    resume = resume || {};
    // 1) Preferred: structured fields (Gemini does NOT control formatting)
    var structured = formatRecruiterNote(resume);
    if (structured) return structured;
    // 2) Backward-compat fallback: Gemini free-form searchNote
    if (resume.searchNote && String(resume.searchNote).trim().length)
      return String(resume.searchNote).trim();
    // 3) Last resort: build clean block from raw fields
    var cand = resume.candidate || {};
    var lines = [];
    var prof = [];
    if (resume.currentEmployment && resume.currentEmployment.title) prof.push(resume.currentEmployment.title);
    if (resume.currentEmployment && resume.currentEmployment.company) prof.push('@ ' + resume.currentEmployment.company);
    var yrs = '';
    if (resume.experience && resume.experience.length) {
      var total = 0;
      for (var i = 0; i < resume.experience.length; i++) {
        var ex = resume.experience[i] || {};
        var a = parseInt((ex.startDate || '').slice(0, 4), 10);
        var b = parseInt((ex.endDate || '').slice(0, 4), 10);
        if (a && b && b >= a) total += (b - a); else if (ex.isCurrent) total += 5;
      }
      if (total > 0) yrs = total + '年';
    }
    var head = '【人才摘要】';
    if (prof.length) head += prof.join(' ') + '。';
    if (yrs) head += yrs + '相關經驗。';
    if (resume.summary) head += String(resume.summary).replace(/\s+/g, ' ').slice(0, 120);
    lines.push(head);
    var kws = [];
    if (resume.skills && resume.skills.length) for (var s = 0; s < resume.skills.length; s++) kws.push(strip(resume.skills[s]));
    if (resume.languages && resume.languages.length) for (var li = 0; li < resume.languages.length; li++) if (!isGenericLang(resume.languages[li])) kws.push(strip(resume.languages[li]));
    if (resume.certifications && resume.certifications.length) for (var ci = 0; ci < resume.certifications.length; ci++) if (!isWeakCert(resume.certifications[ci])) kws.push(strip(resume.certifications[ci]));
    kws = uniq(kws.filter(Boolean)).slice(0, 18);
    if (kws.length) lines.push('【核心關鍵字】' + kws.join('、'));
    return lines.join('\n');
  }
  function strip(v) { return String(v == null ? '' : v).replace(/\s+/g, ' ').trim(); }
  function uniq(a) { var o = {}, r = []; for (var i = 0; i < a.length; i++) { if (!o[a[i]]) { o[a[i]] = 1; r.push(a[i]); } } return r; }

  // Merge AI block into existing Note, preserving recruiter-written text.
  var AI_BLOCK_MARKER = '--- TNT 人才備註 ---';
  var AI_BLOCK_MARKER_OLD = '--- AI Review ---';
  function mergeNote(existing, aiBlock) {
    existing = existing || '';
    var lines = existing.split(/\n/);
    var cut = -1;
    for (var i = 0; i < lines.length; i++) {
      if (lines[i].indexOf(AI_BLOCK_MARKER) >= 0 || lines[i].indexOf(AI_BLOCK_MARKER_OLD) >= 0) { cut = i; break; }
    }
    var recruiter = (cut >= 0 ? lines.slice(0, cut) : lines).join('\n').trim();
    var body = recruiter ? (recruiter + '\n\n' + AI_BLOCK_MARKER + '\n' + aiBlock) : (AI_BLOCK_MARKER + '\n' + aiBlock);
    return body;
  }

  // Integrated AI Review: capture -> Gemini -> fill Name/Phone/Email + Note
  // directly into the ORIGINAL New Talent fields. No separate panel. No second
  // save client. Original Pinpin Save stays canonical.
  // Resolve the resume source. PATH B2: if the current New Talent has an
  // addFileName with a valid LinkedIn session-cache entry, use it (exact match).
  // Otherwise fall back to the detected source (104 or unknown). Returns a Promise
  // resolving to { source, cap, addFileName }.
  function resolveCapture(runId) {
    var st = stateForRun(runId);
    var srcType = detectSource();
    // ROUTING DIAGNOSTIC: mark resolveCapture entered; record detected source.
    try {
      if (!st.routeDiag) st.routeDiag = { click: false, pageHost: (global.location && global.location.hostname || ''), frameTop: (global.top === global.self), runAiReview: false, detectedSource: null, resolveCapture: false, captureForSource: false, profileTextCapture: false, container: false, chars: 0, errorStage: null };
      st.routeDiag.resolveCapture = true;
      st.routeDiag.detectedSource = srcType;
      updateB2DiagBadge();
    } catch (e) {}
    var scope = findAddResumeScope();
    var addFileName = scope && scope.addFileName ? String(scope.addFileName) : '';
    if (srcType === '104') {
      // PRESERVED: the stable, proven 104 capture path. Unchanged.
      return Promise.resolve(captureForSource('104')).then(function (cap) {
        return { source: '104', cap: cap, addFileName: null };
      });
    }
    if (srcType === 'linkedin' || srcType === 'linkedin-recruiter' || srcType === 'linkedin-public') {
      // NEW LinkedIn PATH (post-B2): direct current-profile text capture.
      // No B2 broker / storage.session / addFileName bridge.
      var liSrc = (srcType === 'linkedin-recruiter') ? 'linkedin-recruiter'
        : (srcType === 'linkedin-public') ? 'linkedin-public'
        : 'linkedin';
      return Promise.resolve(captureForSource(liSrc)).then(function (cap) {
        return { source: liSrc, cap: cap, addFileName: null };
      });
    }
    // unknown / unsupported: fail closed (do not degrade to New Talent form clone).
    return Promise.resolve({ source: 'unknown', cap: { source: 'unknown', resumeHtml: '', resumeText: '', error: '不支援的來源，無法執行 AI Fill。' }, addFileName: null });
  }

  function runAiReview(runId) {
    runId = runId || currentRunId;
    var st = stateForRun(runId);
    st.status = 'parsing';
    toast('AI 解析中…');
    // ROUTING DIAGNOSTIC: mark runAiReview entered; record exact detectSource().
    try {
      if (!st.routeDiag) st.routeDiag = { click: false, pageHost: (global.location && global.location.hostname || ''), frameTop: (global.top === global.self), runAiReview: false, detectedSource: null, resolveCapture: false, captureForSource: false, profileTextCapture: false, container: false, chars: 0, errorStage: null };
      st.routeDiag.runAiReview = true;
      st.routeDiag.detectedSource = detectSource();
      updateB2DiagBadge();
    } catch (e) {}
    resolveCapture(runId).then(function (resolved) {
      var source = resolved.source;
      var cap = resolved.cap;
      var addFileName = resolved.addFileName;
      // store non-PII capture status for the badge (no candidate data)
      st.captureStatus = {
        source: cap && cap.source ? cap.source : source,
        characterCount: cap && typeof cap.characterCount === 'number' ? cap.characterCount : (cap && cap.resumeText ? cap.resumeText.length : 0),
        sectionsDetected: cap && cap.sectionsDetected ? cap.sectionsDetected : null,
        error: cap && cap.error ? cap.error : null
      };
      if (!cap || cap.error || (!cap.resumeHtml && !cap.resumeText)) {
        st.status = 'error';
        st.error = (cap && cap.error) || 'LinkedIn 履歷內容擷取不完整，請確認人選頁面已完整載入後再試一次。';
        toast(st.error);
        return; // fail closed
      }
      parseResume({
        runId: runId,
        source: source,
        resumeHtml: cap.resumeHtml || '',
        resumeText: cap.resumeText || '',
        currentPinpinFields: currentPinpinFields()
      }).then(function (res) {
        // Backend/Gemini failure (parseResume resolves with ok:false, no resume)
        // -> RETAIN the cache so William can click AI Fill again. Do NOT delete.
        if (!res || res.ok === false || !res.resume) {
          st.status = 'error';
          st.error = (res && res.error) || 'AI 解析失敗';
          toast('AI 解析失敗，Original New Talent 不受影響；可再點一次 AI Fill');
          return; // cache intentionally retained for retry
        }
        var r = res.resume;
        st.resume = r; st.status = 'complete';
        var scope = findAddResumeScope();
        if (scope) {
          // New Talent is in THIS document -> fill directly (same-tab import).
          var mapped = mapAIResumeToPinpinForm(r, null);
          applyToPinpin(mapped, runId); // writes fields ONLY; no scope.submit
          var noteField = findNoteField();
          if (noteField) {
            var block = buildAiNoteBlock(r);
            var existing = noteField.value || '';
            var merged = mergeNote(existing, block);
            setNativeValue(noteField, merged);
            st.noteFilled = true;
            toast('已填入 Name/Phone/Email + Note，請在 New Talent 確認後按原本 Save');
          } else {
            st.noteFilled = false;
            toast('已填入 Name/Phone/Email；Note 欄位未找到（未寫入 Note）');
          }
        } else {
          // New Talent not in this document. (Should not happen on real New Talent.)
          st.noteFilled = false;
          showResultCard(r);
          toast('已解析（此頁無 New Talent）。請匯入 New Talent 後再用 AI Fill，或複製下方結果');
        }
      }).catch(function (e) {
        // Gemini/parse failure: KEEP the cache so William can retry AI Fill.
        st.status = 'error'; st.error = 'AI 解析失敗';
        toast('AI 解析失敗，Original New Talent 不受影響；可再點一次 AI Fill');
      });
    }).catch(function (e) {
      st.status = 'error';
      st.error = 'LinkedIn 履歷來源已失效，請重新從 LinkedIn 匯入此人選後再使用 AI Fill。';
      toast(st.error);
    });
  }

  // Lightweight status toast near the launcher (no separate panel).
  function showResultCard(resume) {
    resume = resume || {};
    var cand = resume.candidate || {};
    var card = global.document.getElementById('tnai-result-card');
    if (card && card.parentNode) card.parentNode.removeChild(card);
    card = global.document.createElement('div');
    card.id = 'tnai-result-card';
    var block = buildAiNoteBlock(resume);
    card.style.cssText = 'position:fixed;right:12px;top:12px;z-index:2147483647;' +
      'max-width:320px;background:rgba(235,246,255,.94);color:#0b1b3a;' +
      'border:1px solid rgba(120,170,255,.6);border-radius:14px;padding:14px;' +
      'font:12px/1.5 system-ui,sans-serif;box-shadow:0 12px 36px rgba(20,55,90,.3);' +
      'white-space:pre-wrap;max-height:70vh;overflow:auto;';
    var html = '【AI 解析結果】\n姓名: ' + (cand.name || '-') +
      '\n電話: ' + (normalizePhone(cand.phone) || '-') +
      '\nEmail: ' + (cand.email || '-') + '\n\n' + block;
    card.textContent = html;
    (global.document.body || global.document.documentElement).appendChild(card);
    global.setTimeout(function () { if (card.parentNode) card.style.display = 'none'; }, 20000);
  }

  function toast(msg) {
    var t = global.document.getElementById('tnai-toast');
    if (!t) {
      t = global.document.createElement('div');
      t.id = 'tnai-toast';
      t.style.cssText = 'position:fixed;right:12px;bottom:52px;z-index:2147483647;' +
        'background:#0b1b3a;color:#e8eefc;border:1px solid #27406e;border-radius:8px;' +
        'padding:8px 12px;font:600 12px/1.4 system-ui,sans-serif;max-width:280px;' +
        'box-shadow:0 4px 14px rgba(0,0,0,.45);';
      (global.document.body || global.document.documentElement).appendChild(t);
    }
    t.textContent = msg;
    t.style.display = 'block';
    global.clearTimeout(t.__t);
    t.__t = global.setTimeout(function () { if (t.parentNode) t.style.display = 'none'; }, 6000);
  }

  // Floating panel UI (injected once)
  // =========================================================================
  var panelEl = null;

  function ensurePanel() {
    if (panelEl && document.body.contains(panelEl)) return panelEl;
    var host = document.createElement('div');
    host.id = 'tnai-panel-host';
    host.setAttribute('aria-label', 'AI Resume Review');
    host.style.cssText = [
      'position:fixed', 'right:16px', 'bottom:16px', 'z-index:2147483647',
      'width:340px', 'max-height:80vh', 'overflow:auto',
      'background:#0f2e2e', 'color:#eafff6', 'border:1px solid #2bd4a8',
      'border-radius:10px', 'font:13px/1.4 system-ui,sans-serif',
      'box-shadow:0 8px 30px rgba(0,0,0,.4)', 'padding:0'
    ].join(';');
    host.innerHTML =
      '<div style="display:flex;align-items:center;justify-content:space-between;' +
      'background:#173f3c;padding:8px 10px;border-radius:10px 10px 0 0;">' +
      '<strong style="color:#2bd4a8;">✨ AI Resume Review</strong>' +
      '<button id="tnai-close" style="background:none;border:0;color:#e8eefc;cursor:pointer;font-size:16px;">×</button>' +
      '</div>' +
      '<div id="tnai-body" style="padding:10px;"></div>';
    document.body.appendChild(host);
    panelEl = host;
    host.querySelector('#tnai-close').addEventListener('click', function () {
      if (host.parentNode) host.parentNode.removeChild(host);
      panelEl = null;
    });
    return host;
  }

  function renderPanel(runId, opts) {
    opts = opts || {};
    var st = stateForRun(runId);

    // NOTE: NO capture on panel open. Opening AI Review must cause ZERO
    // capture calls, ZERO backend calls, ZERO Gemini calls. Capture happens
    // only on the explicit AI Parse click (see the Parse button handler).

    var host = ensurePanel();
    var body = host.querySelector('#tnai-body');
    var buf = [];

    buf.push('<div style="margin-bottom:6px;">');
    buf.push('Source: <b>' + escapeHtml(st.source || opts.source || 'unknown') + '</b><br>');
    buf.push('Status: <b>' + escapeHtml(st.status) + '</b>');
    if (st.error) buf.push(' <span style="color:#ffb4b4;">(' + escapeHtml(st.error) + ')</span>');
    buf.push('</div>');

    if (st.status === 'parsing') {
      buf.push('<div style="padding:10px 0;">AI analyzing resume…</div>');
    } else if (st.resume) {
      buf.push(renderEditor(st.resume));
    } else {
      buf.push('<div style="opacity:.8;">No AI result yet. Click ✨ AI Parse.</div>');
    }

    buf.push('<div style="margin-top:8px;display:flex;gap:6px;flex-wrap:wrap;">');
    buf.push('<button id="tnai-parse" style="flex:1;background:#3b82f6;color:#04122e;border:0;border-radius:6px;padding:6px;cursor:pointer;">✨ AI Parse</button>');
    buf.push('<button id="tnai-reset" style="background:#173f3c;color:#e8eefc;border:1px solid #27406e;border-radius:6px;padding:6px;cursor:pointer;">Reset</button>');
    buf.push('<button id="tnai-save" style="flex:1;background:#1f8f6e;color:#fff;border:0;border-radius:6px;padding:6px;cursor:pointer;">Save to Pinpin</button>');
    buf.push('</div>');
    buf.push('<div style="margin-top:6px;font-size:11px;opacity:.7;">Switching Original/AI never alters the other. AI edits are not applied until you click Save.</div>');

    body.innerHTML = buf.join('');

    body.querySelector('#tnai-parse').addEventListener('click', function () {
      this.disabled = true;
      var st = stateForRun(runId);
      // Explicit capture ONCE, on this click only. No capture on panel open.
      var source = detectSource();
      // captureForSource may return a Promise (LinkedIn B2 session-cache path)
      // or a synchronous object (104). Normalize to a Promise.
      var capPromise = (typeof captureForSource(source).then === 'function')
        ? captureForSource(source)
        : Promise.resolve(captureForSource(source));
      capPromise.then(function (cap) {
        if (cap.error) {
          // Fail closed: surface the capture error, do NOT call the backend,
          // do NOT touch Original. #addResume is never a 104 fallback.
          st.status = 'error';
          st.error = cap.error;
          renderPanel(runId, opts);
          return;
        }
        parseResume({
          runId: runId,
          source: source,
          resumeHtml: cap.resumeHtml || '',
          resumeText: cap.resumeText || '',
          currentPinpinFields: currentPinpinFields()
        })
          .then(function () { renderPanel(runId, opts); })
          .catch(function () { renderPanel(runId, opts); });
      });
    });
    body.querySelector('#tnai-reset').addEventListener('click', function () {
      clearRun(runId);
      var st2 = stateForRun(runId); st2.status = 'idle';
      renderPanel(runId, opts);
    });
    body.querySelector('#tnai-save').addEventListener('click', function () {
      var st3 = stateForRun(runId);
      if (!st3.resume) { st3.error = 'parse first'; st3.status = 'error'; renderPanel(runId, opts); return; }
      // PERSISTED fields only: chineseName/mobile/email (the identity the
      // canonical submit carries). Experience/education/etc. are review-only
      // in this build — see docs/AI_PINPIN_FIELD_MAPPING.md.
      var mapped = mapAIResumeToPinpinForm(st3.resume, null);
      if (!mapped.chineseName && !mapped.mobile && !mapped.email) {
        st3.error = 'no-identity'; st3.status = 'error'; renderPanel(runId, opts); return;
      }
      var r = applyToPinpin(mapped, runId);
      if (!r.ok) { st3.status = 'error'; st3.error = r.reason; }
      else { st3.status = 'saved'; }
      renderPanel(runId, opts);
    });
  }

  function renderEditor(r) {
    var buf = [];
    buf.push('<div style="border-top:1px solid #2bd4a8;margin:6px 0;padding-top:6px;"><b>Basic (persisted on Save)</b></div>');
    buf.push(field('Name', 'cand.name', r.candidate && r.candidate.name));
    buf.push(field('Phone', 'cand.phone', r.candidate && r.candidate.phone));
    buf.push(field('Email', 'cand.email', r.candidate && r.candidate.email));
    buf.push(field('Location', 'cand.location', r.candidate && r.candidate.location));

    buf.push('<div style="border-top:1px solid #2bd4a8;margin:6px 0;padding-top:6px;"><b>Current Employment (review only)</b></div>');
    buf.push(field('Company', 'cur.company', r.currentEmployment && r.currentEmployment.company));
    buf.push(field('Title', 'cur.title', r.currentEmployment && r.currentEmployment.title));

    buf.push('<div style="border-top:1px solid #2bd4a8;margin:6px 0;padding-top:6px;"><b>Summary (review only)</b></div>');
    buf.push(textarea('summary', r.summary));

    buf.push('<div style="opacity:.7;font-size:11px;margin-top:6px;color:#8aa0c8;">On Save, only <b>Name / Phone / Email</b> are written to Pinpin New Talent via the existing Save button. Experience / Education / Skills / Summary are review-only here: the canonical Pinpin submit stores the full resume from the captured file (addFileName), not from these fields. See AI_PINPIN_FIELD_MAPPING.md.</div>');
    return buf.join('');
  }

  function field(label, key, val) {
    return '<label style="display:block;margin:3px 0;">' + escapeHtml(label) +
      '<input data-rk="' + escapeHtml(key) + '" value="' + escapeHtml(val || '') +
      '" style="width:100%;box-sizing:border-box;background:#0b2422;color:#e8eefc;border:1px solid #27406e;border-radius:4px;padding:4px;"></label>';
  }
  function textarea(key, val) {
    return '<textarea data-rk="' + escapeHtml(key) + '" style="width:100%;box-sizing:border-box;background:#0b2422;color:#e8eefc;border:1px solid #27406e;border-radius:4px;padding:4px;height:54px;">' +
      escapeHtml(val || '') + '</textarea>';
  }
  function escapeHtml(v) {
    return String(v == null ? '' : v).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }

  // =========================================================================
  // Public API
  // =========================================================================
  global.TNAI = {
    setApiBaseUrl: setApiBaseUrl,
    setMockMode: setMockMode,
    getApiBaseUrl: function () { return AI_API_BASE_URL; },
    isMockMode: function () { return AI_MOCK_MODE; },
    parseResume: parseResume,
    captureForSource: captureForSource,

    mapAIResumeToPinpinForm: mapAIResumeToPinpinForm,
    normalizePhone: normalizePhone,
    buildAiNoteBlock: buildAiNoteBlock,
    mergeNote: mergeNote,
    applyToPinpin: applyToPinpin,
    findAddResumeScope: findAddResumeScope,
    getPinpinResume: getPinpinResume,
    renderPanel: renderPanel,
    clearRun: clearRun,
    stateForRun: stateForRun
  };

  // =========================================================================
  // New Talent visual theme: frosted light-blue glass, matching the AI Review
  // look. Pure CSS overlay on Pinpin's own New Talent page — NO HTML/function
  // change to Pinpin (Original Save / auth untouched). Injected only while the
  // live AddResumeCtrl is active, removed on unmount. Reversible / scoped.
  var TNAI_BRAND_ID = 'tnai-brand-bar';
  function applyNewTalentBranding() {
    if (global.document.getElementById(TNAI_BRAND_ID)) return;
    var root = global.document.getElementById('addResume');
    if (!root) return;
    var header = root.querySelector('.header, .title-bar, .topbar, .card-header, .panel-head, header') || root.querySelector('h1, h2, h3');
    var bar = global.document.createElement('div');
    bar.id = TNAI_BRAND_ID;
    bar.style.cssText = 'display:flex;flex-direction:column;gap:2px;padding:6px 4px 10px;' +
      'margin:-4px 0 10px;border-bottom:1px solid rgba(120,170,255,.4);' +
      'background:rgba(232,245,255,.82);-webkit-backdrop-filter:blur(16px) saturate(140%);' +
      'backdrop-filter:blur(16px) saturate(140%);border-radius:14px 14px 0 0;';
    bar.innerHTML = '<div style="font:800 18px/1.2 system-ui,sans-serif;color:#0b2a5b;letter-spacing:.3px;">Talent Nexus AI Connector</div>' +
      '<div style="font:500 12px/1.2 system-ui,sans-serif;color:#2b5a9e;">AI-assisted candidate intelligence</div>';
    if (header && header.parentNode) {
      header.style.display = 'none';
      header.parentNode.insertBefore(bar, header);
    } else {
      root.insertBefore(bar, root.firstChild);
    }
  }
  function removeNewTalentBranding() {
    var b = global.document.getElementById(TNAI_BRAND_ID);
    if (b && b.parentNode) b.parentNode.removeChild(b);
  }

  var TNAI_THEME_ID = 'tnai-newtalent-theme';
  function applyNewTalentTheme() {
    if (global.document.getElementById(TNAI_THEME_ID)) return;
    var root = global.document.getElementById('addResume');
    if (!root) return;
    var style = global.document.createElement('style');
    style.id = TNAI_THEME_ID;
    style.textContent = [
      '#addResume{',
      '  background: rgba(235, 246, 255, 0.78) !important;',
      '  -webkit-backdrop-filter: blur(16px) saturate(140%) !important;',
      '  backdrop-filter: blur(16px) saturate(140%) !important;',
      '  border: 1px solid rgba(255, 255, 255, 0.65) !important;',
      '  border-radius: 18px !important;',
      '  box-shadow: 0 16px 45px rgba(20, 55, 90, 0.15) !important;',
      '  padding: 18px 20px !important;',
      '  color: #0b1b3a !important;',
      '}',
      '#addResume input, #addResume textarea, #addResume select{',
      '  background: rgba(255, 255, 255, 0.72) !important;',
      '  border: 1px solid rgba(120, 170, 255, 0.45) !important;',
      '  border-radius: 10px !important;',
      '  color: #0b1b3a !important;',
      '  padding: 7px 10px !important;',
      '}',
      '#addResume input:focus, #addResume textarea:focus, #addResume select:focus{',
      '  border: 1px solid rgba(59, 130, 246, 0.95) !important;',
      '  outline: none !important;',
      '  box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.18) !important;',
      '}',
      '#addResume label, #addResume .section-title, #addResume h1, #addResume h2, #addResume h3{',
      '  color: #13386e !important;',
      '}',
      // Top header / title bar of New Talent -> light blue glass to match AI Fill
      '#addResume .header, #addResume .title-bar, #addResume .topbar, #addResume > header, #addResume .card-header, #addResume .panel-head{',
      '  background: rgba(235, 246, 255, 0.72) !important;',
      '  -webkit-backdrop-filter: blur(16px) saturate(140%) !important;',
      '  backdrop-filter: blur(16px) saturate(140%) !important;',
      '  border-bottom: 1px solid rgba(120, 170, 255, 0.4) !important;',
      '  border-radius: 18px 18px 0 0 !important;',
      '  color: #13386e !important;',
      '}',
      // Pinpin Original Save button -> solid Talent Nexus blue (clearly the
      // primary persist action). Distinct from AI Fill (glass gradient) so the
      // user still reads: AI Fill = fill, Save = persist.
      '#addResume button:not(#tnai-launcher), #addResume input[type=submit], #addResume .btn-save, #addResume .save-btn{',
      '  background: linear-gradient(135deg, #2563eb, #3b82f6) !important;',
      '  color: #ffffff !important;',
      '  border: 1px solid rgba(255,255,255,.5) !important;',
      '  border-radius: 12px !important;',
      '  padding: 10px 20px !important;',
      '  font: 700 14px/1 system-ui, sans-serif !important;',
      '  cursor: pointer !important;',
      '  box-shadow: 0 8px 22px rgba(30,80,180,.35) !important;',
      '}',
      '#addResume button:not(#tnai-launcher):hover, #addResume input[type=submit]:hover{',
      '  filter: brightness(1.06) !important;',
      '}'
    ].join('\n');
    (global.document.head || global.document.documentElement).appendChild(style);
    applyNewTalentBranding();
    log('new-talent theme applied');
  }
  function removeNewTalentTheme() {
    var t = global.document.getElementById(TNAI_THEME_ID);
    if (t && t.parentNode) t.parentNode.removeChild(t);
    removeNewTalentBranding();
  }

  // =========================================================================
  // Floating launcher (entry point the user actually sees)
  // =========================================================================
  // The panel is rendered on demand. We mount a small floating trigger so the
  // AI Review feature is discoverable on the New Talent page — without ever
  // auto-modifying the Original workflow. Clicking it opens the panel.
  // TEMPORARY non-PII diagnostic badge (live B2 debugging only). Always
  // visible beside AI Fill so the running build + each transport stage can be
  // confirmed WITHOUT DevTools. Removed after the live retest passes.
  var TNAI_B2_BUILD = 'a0aab81';
  function updateB2DiagBadge() {
    try {
      var st = stateForRun(currentRunId);
      var rd = (st && st.routeDiag) || null;
      var cs = (st && st.captureStatus) || null;
      var badge = global.document.getElementById('tnai-b2-diag');
      if (!badge) {
        badge = global.document.createElement('div');
        badge.id = 'tnai-b2-diag';
        badge.style.cssText = 'position:fixed;right:12px;bottom:54px;z-index:2147483647;max-width:320px;' +
          'background:rgba(20,40,70,.92);color:#cfe3ff;border:1px solid rgba(120,170,255,.5);' +
          'border-radius:8px;padding:6px 8px;font:600 10px/1.4 system-ui,sans-serif;white-space:pre-wrap;';
        (global.document.body || global.document.documentElement).appendChild(badge);
      }
      var y = function (v) { return v ? 'Y' : 'N'; };
      var lines = [];
      lines.push('LinkedIn Capture');
      lines.push('click: ' + (rd ? y(rd.click) : 'N'));
      lines.push('runAiReview: ' + (rd ? y(rd.runAiReview) : 'N'));
      lines.push('detectedSource: ' + (rd && rd.detectedSource ? rd.detectedSource : '-'));
      if (rd && rd.pageHost) lines.push('pageHost: ' + rd.pageHost);
      if (rd && rd.frameTop === false) lines.push('frame: IFRAME(not top)');
      lines.push('resolveCapture: ' + (rd ? y(rd.resolveCapture) : 'N'));
      lines.push('captureForSource: ' + (rd ? y(rd.captureForSource) : 'N'));
      lines.push('profileTextCapture: ' + (rd ? y(rd.profileTextCapture) : 'N'));
      lines.push('source: ' + (cs ? cs.source : '-'));
      lines.push('rootStrategy: ' + (rd && rd.rootStrategy ? rd.rootStrategy : '-'));
      lines.push('rootCandidates: ' + (rd && rd.rootCandidates ? rd.rootCandidates : '-'));
      lines.push('rawRoot: ' + (rd && rd.rawRootChars != null ? rd.rawRootChars : '-') + ' chars');
      lines.push('cloneBeforeFilter: ' + (rd && rd.cloneBeforeFilterChars != null ? rd.cloneBeforeFilterChars : '-') + ' chars');
      lines.push('afterCardRef: ' + (rd && rd.afterCardRefFilterChars != null ? rd.afterCardRefFilterChars : '-') + ' chars');
      lines.push('afterNoise: ' + (rd && rd.afterNoiseRemovalChars != null ? rd.afterNoiseRemovalChars : '-') + ' chars');
      lines.push('finalText: ' + (rd && rd.finalTextChars != null ? rd.finalTextChars : '-') + ' chars');
      lines.push('container: ' + (rd ? y(rd.container) : '-'));
      lines.push('text: ' + (cs ? (cs.characterCount || 0) : (rd ? rd.chars || 0 : 0)) + ' chars');
      lines.push('errorStage: ' + (rd && rd.errorStage ? rd.errorStage : '-'));
      if (cs && cs.error) lines.push('note: ' + cs.error);
      badge.textContent = lines.join('\n');
    } catch (e) {}
  }
  function mountLauncher() {
    if (global.document.getElementById('tnai-launcher')) return;
    var btn = global.document.createElement('button');
    btn.id = 'tnai-launcher';
    btn.textContent = '✨ AI Fill';
    btn.style.cssText =
      'position:fixed;right:12px;bottom:12px;z-index:2147483647;' +
      'background:linear-gradient(135deg,rgba(59,130,246,.92),rgba(99,102,241,.92));' +
      'color:#fff;border:1px solid rgba(255,255,255,.6);border-radius:12px;' +
      'padding:10px 16px;font:700 13px/1 system-ui,sans-serif;cursor:pointer;' +
      '-webkit-backdrop-filter:blur(8px);backdrop-filter:blur(8px);' +
      'box-shadow:0 8px 24px rgba(30,80,180,.35);';
    // Single action: capture current 104 resume -> Gemini -> fill the ORIGINAL
    // New Talent fields (Name/Phone/Email + Note). No separate panel. Original
    // Pinpin Save remains canonical.
    btn.addEventListener('click', function () {
      log('launcher -> AI fill run=' + currentRunId);
      // ROUTING DIAGNOSTIC (non-PII): record click + page/frame context.
      try {
        var st = stateForRun(currentRunId);
        st.routeDiag = {
          click: true,
          pageHost: (global.location && global.location.hostname || '') + '',
          frameTop: (global.top === global.self),
          runAiReview: false, detectedSource: null, resolveCapture: false,
          captureForSource: false, profileTextCapture: false,
          container: false, chars: 0, errorStage: null
        };
        updateB2DiagBadge();
      } catch (e) {}
      runAiReview(currentRunId);
    });
    (global.document.body || global.document.documentElement).appendChild(btn);
    applyNewTalentTheme();
    updateB2DiagBadge();
    log('launcher mounted');
  }

  function removeLauncher() {
    var b = global.document.getElementById('tnai-launcher');
    if (b && b.parentNode) b.parentNode.removeChild(b);
    removeNewTalentTheme();
  }

  // STRICT guard (CASE A, ISOLATED world, no postMessage).
  // Launcher appears ONLY while the live AddResumeCtrl exists AND the Golden
  // Base active flag (scope.$root.add_resume) is set. No URL/iframe/origin
  // dependency. This guarantees NO launcher on 104 / LinkedIn / unrelated
  // pages — only the real New Talent context.
  var currentRunId = null;

  function computeRunId() {
    var s = findAddResumeScope();
    if (s && s.addFileName) return String(s.addFileName);
    return getSessionKey(); // unique per New Talent instance; never shared
  }

  function isNewTalentActive() {
    var s = findAddResumeScope();
    if (!s) return false;
    return !!(s.$root && s.$root.add_resume);
  }
  function isLinkedInActive() {
    try {
      var h = (global.location && global.location.hostname || '').toLowerCase();
      return h.indexOf('linkedin.com') >= 0;
    } catch (e) { return false; }
  }

  function syncLauncher() {
    if (isNewTalentActive()) {
      currentRunId = computeRunId();
      if (!global.document.getElementById('tnai-launcher')) mountLauncher();
      log('active run=' + currentRunId);
    } else {
      removeLauncher(); // New Talent closed / route changed -> hide launcher
      var ph = global.document.getElementById('tnai-panel-host');
      if (ph && ph.parentNode) ph.parentNode.removeChild(ph);
    }
  }

  function boot() {
    if (!global.document) return;
    // [TNAI][frame diag] safe: origin + pathname + top-frame flag only.
    try {
      log('loaded href=' + (global.location.origin + global.location.pathname) +
          ' top=' + (global.window === global.top));
    } catch (e) { log('loaded (location unknown)'); }

    // Poll so we detect when New Talent opens/closes (SPA, no reliable event).
    var tries = 0;
    var timer = global.setInterval(function () {
      tries++;
      syncLauncher();
      if (tries > 240) { global.clearInterval(timer); } // ~2min safety stop
    }, 500);
  }

  log('module loaded (additive; Original New Talent untouched)');
  boot();
})(typeof window !== 'undefined' ? window : this);
