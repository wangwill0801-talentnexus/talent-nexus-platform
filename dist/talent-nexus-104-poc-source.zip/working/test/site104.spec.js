/*
 * jsdom behaviour tests for the 104 adapter. Synthetic anonymized DOM only —
 * no real candidate data. Run: node test/site104.spec.js
 */
const fs = require('fs');
const path = require('path');
const { JSDOM } = require('jsdom');

let pass = 0, fail = 0;
function ok(name, cond, extra) {
  if (cond) { pass++; console.log('  PASS  ' + name); }
  else { fail++; console.log('  FAIL  ' + name + (extra ? ' :: ' + extra : '')); }
}

const ADAPTER = fs.readFileSync(
  path.join(__dirname, '..', 'js', 'versions', 'v1', 'sites', 'site104.js'), 'utf8');

function build(html, url) {
  const dom = new JSDOM(html, {
    url: url || 'https://vip.104.com.tw/search/SearchResumeMaster?x=1',
    runScripts: 'outside-only'
  });
  const w = dom.window;
  w.eval(ADAPTER);
  return w;
}

const RESUME_HTML = `<!doctype html><html lang="zh-TW"><head><title>t</title>
<script>var tracking=1;</script></head><body>
<header class="site-header">導覽列 首頁</header>
<nav class="main-nav">選單</nav>
<div class="resume-master-layout search-resume-master">
  <div class="vip-resume-card resume-card">
    <div class="name">候選人 A</div>
    <div class="code">履歷代碼 R-0001</div>
    <a href="mailto:undefined">聯絡信箱</a>
    <div class="phone"></div>
    <div class="current">目前任職 範例股份有限公司 / 專案經理</div>
  </div>
  <div class="standard-resume-wrapper">
    <article class="standard-resume">
      <section class="exp"><h3>工作經歷</h3><p>2019/01 - 迄今 範例股份有限公司 專案經理 負責專案交付</p></section>
      <section class="edu"><h3>教育背景</h3><p>範例大學 資訊管理 學士</p></section>
      <section class="skill"><h3>技能</h3><p>JavaScript, SQL</p></section>
      <section class="lang"><h3>語文能力</h3><p>中文, 英文</p></section>
      <section class="pref"><h3>求職條件</h3><p>希望職稱 專案經理</p></section>
      <section class="auto"><h3>自傳</h3><p>自我介紹內容。</p></section>
      <div class="company-remark">內部備註：招募顧問 王小明 已聯繫，電話 0900-000-000</div>
    </article>
  </div>
  <aside class="sidebar">側邊欄</aside>
  <div class="recommend"><h4>推薦相似人選</h4><p>候選人 B</p></div>
  <div class="modal interview-dialog">面試邀約對話框</div>
  <iframe src="https://ads.example.com"></iframe>
  <div id="kpBox">外掛自身 UI</div>
</div>
<div class="floating chatbot">客服機器人</div>
<footer>頁尾</footer>
</body></html>`;

console.log('\n== detection: positives ==');
{
  const w = build(RESUME_HTML);
  ok('full resume page detected', w.TN104.isResumePage() === true);
}
{
  const w = build(`<body><div class="vip-resume-card resume-card">卡片</div></body>`,
    'https://vip.104.com.tw/anything');
  ok('card-only (no route) detected', w.TN104.isResumePage() === true);
}
{
  const w = build(`<body><div class="standard-resume">內容</div></body>`,
    'https://vip.104.com.tw/x');
  ok('.standard-resume detected', w.TN104.isResumePage() === true);
}
{
  const w = build(`<body><div>工作經歷</div><div>教育背景</div></body>`,
    'https://vip.104.com.tw/search/SearchResumeMaster');
  ok('route + 2 semantic labels detected', w.TN104.isResumePage() === true);
}

console.log('\n== detection: negatives ==');
{
  const w = build(RESUME_HTML, 'https://www.104.com.tw/search/SearchResumeMaster');
  ok('wrong host rejected', w.TN104.isResumePage() === false);
}
{
  const w = build(RESUME_HTML.replace(/vip\.104/g, 'x'), 'https://www.linkedin.com/in/someone');
  ok('linkedin rejected', w.TN104.isResumePage() === false);
}
{
  const w = build(`<body><h1>104 人力銀行 企業首頁</h1><a href="/job">刊登職缺</a></body>`,
    'https://vip.104.com.tw/');
  ok('vip homepage rejected', w.TN104.isResumePage() === false);
}
{
  const w = build(`<body><div>工作經歷</div></body>`,
    'https://vip.104.com.tw/search/SearchResumeMaster');
  ok('route + only 1 semantic label rejected', w.TN104.isResumePage() === false);
}
{
  const w = build(`<body><div>職缺管理列表</div></body>`, 'https://vip.104.com.tw/job/manage');
  ok('unrelated vip page rejected', w.TN104.isResumePage() === false);
}

console.log('\n== capture ==');
{
  const w = build(RESUME_HTML);
  const r = w.TN104.capture104Resume();
  ok('capture ok', r.ok === true);
  ok('capture mode = card+wrapper', r.mode === 'card+wrapper', r.mode);
  ok('chars > 0 and reported', r.chars === r.html.length && r.chars > 0);
  ok('has doctype + zh-TW', /^<!doctype html><html lang="zh-TW">/.test(r.html));
  ok('has 104-summary section', r.html.indexOf('data-source="104-summary"') > -1);
  ok('has 104-resume section', r.html.indexOf('data-source="104-resume"') > -1);

  console.log('\n== preserved resume content ==');
  ['候選人 A','R-0001','範例股份有限公司','專案經理','工作經歷','2019/01',
   '教育背景','範例大學','資訊管理','技能','JavaScript','語文能力',
   '求職條件','自傳'].forEach(t =>
    ok('preserved: ' + t, r.html.indexOf(t) > -1));

  console.log('\n== excluded noise (absent from payload) ==');
  ['導覽列','選單','側邊欄','推薦相似人選','候選人 B','面試邀約對話框',
   '客服機器人','頁尾','外掛自身 UI','ads.example.com','tracking'].forEach(t =>
    ok('absent: ' + t, r.html.indexOf(t) === -1));
  ok('absent: <script', r.html.toLowerCase().indexOf('<script') === -1);
  ok('absent: <iframe', r.html.toLowerCase().indexOf('<iframe') === -1);

  console.log('\n== internal remarks separated AND removed ==');
  const remark = w.TN104.extractInternalRemarkText();
  ok('remark text extracted', remark.indexOf('王小明') > -1, remark);
  ok('remark NOT in parser payload (name)', r.html.indexOf('王小明') === -1);
  ok('remark NOT in parser payload (phone)', r.html.indexOf('0900-000-000') === -1);

  console.log('\n== live DOM untouched ==');
  ok('remark still in live DOM', w.document.body.textContent.indexOf('王小明') > -1);
  ok('header still in live DOM', !!w.document.querySelector('header.site-header'));
  ok('iframe still in live DOM', !!w.document.querySelector('iframe'));
}

console.log('\n== masked contact (STATE B) tolerated ==');
{
  const w = build(RESUME_HTML);
  ok('detected with mailto:undefined + blank phone', w.TN104.isResumePage() === true);
  ok('capture still succeeds', w.TN104.capture104Resume().ok === true);
}

console.log('\n== fallback ladder ==');
{
  const w = build(`<body><div class="resume-master-layout search-resume-master">
    <div class="standard-resume"><p>工作經歷 教育背景</p></div></div></body>`,
    'https://vip.104.com.tw/search/SearchResumeMaster');
  ok('mode = standard-resume', w.TN104.capture104Resume().mode === 'standard-resume');
}
{
  const w = build(`<body><div class="resume-master-layout search-resume-master">
    <article><p>工作經歷 教育背景</p></article></div></body>`,
    'https://vip.104.com.tw/search/SearchResumeMaster');
  ok('mode = layout-article', w.TN104.capture104Resume().mode === 'layout-article');
}
{
  const w = build(`<body><p>工作經歷</p><p>教育背景</p></body>`,
    'https://vip.104.com.tw/search/SearchResumeMaster');
  ok('mode = body-fallback', w.TN104.capture104Resume().mode === 'body-fallback');
}

console.log('\n== integration wiring ==');
{
  const w = build(RESUME_HTML);
  let got = null;
  w.checkRepeat = (html, click) => { got = { html, click }; };
  ok('check() returns true', w.TN104.check('click') === true);
  ok('checkRepeat called with html', !!got && got.html.length > 100);
  ok('checkRepeat click type forwarded', got.click === 'click');
  ok('checkRepeat payload has no remark', got.html.indexOf('王小明') === -1);
}
{
  const w = build(RESUME_HTML);
  let sent = null;
  w.Config = { api: 'https://example.invalid' };
  w.utils = { message: { sendMsg: m => { sent = m; } } };
  ok('addResume() returns true', w.TN104.addResume() === true);
  ok('type = request.api.addResume.normal', sent.type === 'request.api.addResume.normal');
  const body = JSON.parse(sent.settings.data.data);
  ok('payload html array', Array.isArray(body.html) && body.html.length === 1);
  ok('payload host from Config', body.host === 'https://example.invalid');
  ok('payload _id empty', body._id === '');
  ok('payload has no remark', body.html[0].indexOf('王小明') === -1);
}

// REGRESSION: the legacy chains use a BARE `Config.api` (declared `var Config`
// in js/page.js), not `window.Config`. The first build read only
// `global.Config` and silently shipped host:'' — capture worked, but save and
// the status dropdown did nothing because the import file was never bound.
// Reported from the field 2026-08-08.
console.log('\n== Config.api resolution (field regression) ==');
{
  // Bare `var Config` in the shared script scope, NOT set on window.
  const w = build(RESUME_HTML);
  let sent = null;
  w.utils = { message: { sendMsg: m => { sent = m; } } };
  w.eval('var Config = { api: "https://bare.invalid" };');
  const hadWindowConfig = typeof w.Config !== 'undefined' && w.Config !== undefined;
  w.TN104.addResume();
  const body = JSON.parse(sent.settings.data.data);
  ok('host resolved from bare Config identifier', body.host === 'https://bare.invalid',
     'got "' + body.host + '" (window.Config visible: ' + hadWindowConfig + ')');
  ok('host is never empty when Config exists', body.host !== '');
}
{
  // window.Config only — must still work.
  const w = build(RESUME_HTML);
  let sent = null;
  w.utils = { message: { sendMsg: m => { sent = m; } } };
  w.Config = { api: 'https://win.invalid' };
  w.TN104.addResume();
  ok('host resolved from window.Config fallback',
     JSON.parse(sent.settings.data.data).host === 'https://win.invalid');
}
{
  // No Config at all — must not throw, must warn, must still send.
  const w = build(RESUME_HTML);
  let sent = null;
  const warnings = [];
  w.utils = { message: { sendMsg: m => { sent = m; } } };
  w.console.log = (...a) => { warnings.push(a.join(' ')); };
  const rv = w.TN104.addResume();
  ok('no Config: does not throw, still returns true', rv === true);
  ok('no Config: host is ""', JSON.parse(sent.settings.data.data).host === '');
  ok('no Config: warns loudly', warnings.some(l => l.indexOf('Config.api unresolved') > -1));
  ok('no Config: logs hostResolved=false',
     warnings.some(l => l.indexOf('hostResolved=false') > -1));
}
{
  const w = build(`<body></body>`, 'https://vip.104.com.tw/');
  let called = false;
  w.checkRepeat = () => { called = true; };
  const r = w.TN104.capture104Resume();
  ok('empty body -> no capture', r.ok === false && r.mode === 'none');
  ok('check() false when nothing captured', w.TN104.check() === false && called === false);
}

console.log('\n== textOf guard ==');
{
  const w = build(`<body><div id="a">文字</div></body>`, 'https://vip.104.com.tw/');
  const el = w.document.getElementById('a');
  ok('textOf works without innerText', w.TN104._internal.textOf(el) === '文字');
  ok('textOf(null) = ""', w.TN104._internal.textOf(null) === '');
}

console.log('\n----------------------------------------');
console.log(`  ${pass} passed, ${fail} failed`);
console.log('----------------------------------------\n');
process.exit(fail ? 1 : 0);
