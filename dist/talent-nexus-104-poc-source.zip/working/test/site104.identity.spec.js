/*
 * Reproduction: wrong-candidate identity contamination.
 *
 * On vip.104.com.tw SearchResumeMaster the left pane is a LIST of candidate
 * cards (.vip-resume-card.resume-card) and the right pane is the OPENED
 * candidate's resume (.standard-resume-wrapper).
 *
 * capture104Resume() picks the card with querySelector -> the FIRST card in
 * the list, which is NOT necessarily the opened candidate. The payload then
 * contains: summary of candidate B + resume of candidate A.
 *
 * Pinpin's parser reads identity from the leading summary section, so it
 * creates candidate B. This reproduces the reported live bug.
 *
 * Synthetic anonymized DOM only. Names are ANON-A / ANON-B placeholders.
 * Run: node test/site104.identity.spec.js
 */
const fs = require('fs');
const path = require('path');
const { JSDOM } = require('jsdom');

let pass = 0, fail = 0;
const ok = (n, c, x) => { c ? (pass++, console.log('  PASS  ' + n))
  : (fail++, console.log('  FAIL  ' + n + (x ? ' :: ' + x : ''))); };

const SRC = fs.readFileSync(
  path.join(__dirname, '..', 'js', 'versions', 'v1', 'sites', 'site104.js'), 'utf8');

// A search-results page: 3 candidate cards in a list, candidate ANON-A opened.
// ANON-B is the FIRST card (a different person, with their own phone).
const LIST_PAGE = `
<div class="resume-master-layout search-resume-master">
  <div class="resume-list">
    <div class="vip-resume-card resume-card" data-id="B">
      <h3>ANON-B</h3><span>0911111111</span><span>anon-b@example.invalid</span>
      <p>B Corp | B Title</p>
    </div>
    <div class="vip-resume-card resume-card" data-id="C">
      <h3>ANON-C</h3><span>0922222222</span>
    </div>
    <div class="vip-resume-card resume-card active" data-id="A">
      <h3>ANON-A</h3><span>0933333333</span><span>anon-a@example.invalid</span>
      <p>A Corp | A Title</p>
    </div>
  </div>
  <div class="standard-resume-wrapper" data-id="A">
    <div class="standard-resume">
      <h2>ANON-A</h2>
      <section><h3>工作經歷</h3>
        <div data-e2e="experience-list">
          <div data-e2e="experience-list__detail">
            <span class="experience-list-list__companyName">A Corp</span>
            <span class="experience-list-list__jobName">A Title</span>
            <span data-e2e="experience-list__duration">2020/01 - 2024/06</span>
            <p class="experience-list-list__description">Did A things.</p>
          </div>
        </div>
      </section>
      <section><h3>教育背景</h3><p>A University | Information Management</p></section>
      <section><h3>自傳</h3><p>About ANON-A.</p></section>
    </div>
  </div>
</div>`;

function build(html, url) {
  const dom = new JSDOM('<!doctype html><html><body>' + html + '</body></html>', {
    url: url || 'https://vip.104.com.tw/hunter/master?id=A',
    runScripts: 'outside-only'
  });
  const w = dom.window;
  w.eval(SRC);
  return w;
}

console.log('\n== the page really does contain multiple candidates ==');
{
  const w = build(LIST_PAGE);
  const cards = w.document.querySelectorAll('.vip-resume-card.resume-card');
  ok('3 candidate cards present', cards.length === 3, String(cards.length));
  ok('first card is NOT the opened candidate',
     cards[0].getAttribute('data-id') === 'B');
  ok('opened resume is candidate A',
     w.document.querySelector('.standard-resume-wrapper').getAttribute('data-id') === 'A');
}

console.log('\n== CONTAMINATION CHECK (this is the live bug) ==');
{
  const w = build(LIST_PAGE);
  const r = w.TN104.capture104Resume();
  ok('capture succeeds', r.ok);

  const hasA = r.html.includes('ANON-A');
  const hasB = r.html.includes('ANON-B');
  const hasC = r.html.includes('ANON-C');
  const hasBPhone = r.html.includes('0911111111');
  const hasAPhone = r.html.includes('0933333333');

  console.log(`     payload: A=${hasA} B=${hasB} C=${hasC} Bphone=${hasBPhone} Aphone=${hasAPhone}`);

  ok('payload contains the OPENED candidate (A)', hasA);
  ok('payload must NOT contain candidate B', !hasB, 'B leaked into parser input');
  ok('payload must NOT contain candidate C', !hasC, 'C leaked into parser input');
  ok('payload must NOT contain B phone', !hasBPhone, 'wrong mobile source');

  // Identity ordering: whatever appears FIRST is what the parser treats as
  // the candidate. It must be A, never B.
  const iA = r.html.indexOf('ANON-A');
  const iB = r.html.indexOf('ANON-B');
  ok('first identity in payload is A', iA > -1 && (iB === -1 || iA < iB),
     `iA=${iA} iB=${iB}`);
}

console.log('\n== the opened candidate must be selected, not the first card ==');
{
  const w = build(LIST_PAGE);
  const r = w.TN104.capture104Resume();
  ok('resume body present (work history preserved)',
     r.html.includes('A Corp') && r.html.includes('A Title'));
  ok('duration preserved', r.html.includes('2020/01 - 2024/06'));
  ok('education preserved', r.html.includes('A University'));
  ok('autobiography preserved', r.html.includes('About ANON-A'));
  ok('no other-candidate company leaked', !r.html.includes('B Corp'));
}

console.log('\n== single-candidate page still works (no regression) ==');
{
  const SINGLE = `
  <div class="resume-master-layout search-resume-master">
    <div class="vip-resume-card resume-card" data-id="A">
      <h3>ANON-A</h3><span>0933333333</span>
    </div>
    <div class="standard-resume-wrapper" data-id="A">
      <div class="standard-resume"><h2>ANON-A</h2>
        <section><h3>工作經歷</h3><p>A Corp</p></section>
      </div>
    </div>
  </div>`;
  const w = build(SINGLE);
  const r = w.TN104.capture104Resume();
  ok('capture succeeds', r.ok);
  ok('contains candidate A', r.html.includes('ANON-A'));
  ok('summary still included', r.html.includes('0933333333'));
}

console.log('\n== selection strategies (each must pick A, never B) ==');
{
  const variants = {
    'active-class': `
      <div class="resume-master-layout search-resume-master">
        <div class="vip-resume-card resume-card"><h3>ANON-B</h3><span>0911111111</span></div>
        <div class="vip-resume-card resume-card is-selected"><h3>ANON-A</h3><span>0933333333</span></div>
        <div class="standard-resume-wrapper"><div class="standard-resume"><h2>ANON-A</h2>
          <section><h3>工作經歷</h3><p>A Corp</p></section></div></div>
      </div>`,
    'aria-selected': `
      <div class="resume-master-layout search-resume-master">
        <div class="vip-resume-card resume-card"><h3>ANON-B</h3><span>0911111111</span></div>
        <div class="vip-resume-card resume-card" aria-selected="true"><h3>ANON-A</h3><span>0933333333</span></div>
        <div class="standard-resume-wrapper"><div class="standard-resume"><h2>ANON-A</h2>
          <section><h3>工作經歷</h3><p>A Corp</p></section></div></div>
      </div>`,
    'url-id': `
      <div class="resume-master-layout search-resume-master">
        <div class="vip-resume-card resume-card" data-id="B"><h3>ANON-B</h3><span>0911111111</span></div>
        <div class="vip-resume-card resume-card" data-id="A"><h3>ANON-A</h3><span>0933333333</span></div>
        <div class="standard-resume-wrapper"><div class="standard-resume"><h2>ANON-A</h2>
          <section><h3>工作經歷</h3><p>A Corp</p></section></div></div>
      </div>`
  };

  for (const [label, html] of Object.entries(variants)) {
    const url = label === 'url-id'
      ? 'https://vip.104.com.tw/hunter/master?id=A'
      : 'https://vip.104.com.tw/hunter/master';
    const w = build(html, url);
    const r = w.TN104.capture104Resume();
    ok(label + ': A present', r.html.includes('ANON-A'));
    ok(label + ': B absent', !r.html.includes('ANON-B'), 'B leaked');
    ok(label + ': B phone absent', !r.html.includes('0911111111'));
  }
}

console.log('\n== ambiguous list: omit summary rather than guess wrong ==');
{
  // Two cards, no id, no active class, no URL id -> cannot tell who is open.
  const AMBIG = `
  <div class="resume-master-layout search-resume-master">
    <div class="vip-resume-card resume-card"><h3>ANON-B</h3><span>0911111111</span></div>
    <div class="vip-resume-card resume-card"><h3>ANON-A</h3><span>0933333333</span></div>
    <div class="standard-resume-wrapper"><div class="standard-resume"><h2>ANON-A</h2>
      <section><h3>工作經歷</h3><p>A Corp</p></section>
      <section><h3>教育背景</h3><p>A University</p></section></div></div>
  </div>`;
  const w = build(AMBIG, 'https://vip.104.com.tw/hunter/master');
  const r = w.TN104.capture104Resume();
  ok('capture still succeeds', r.ok);
  ok('mode falls back to wrapper only', r.mode === 'wrapper', r.mode);
  ok('NO card summary included', !r.html.includes('0911111111') &&
     !r.html.includes('0933333333'));
  ok('candidate B never present', !r.html.includes('ANON-B'));
  ok('resume body still captured', r.html.includes('A Corp') &&
     r.html.includes('A University'));
  ok('opened candidate name still present (from resume)', r.html.includes('ANON-A'));
}

console.log('\n== stale state: consecutive captures must not bleed ==');
{
  const mk = (id, name, phone) => `
  <div class="resume-master-layout search-resume-master">
    <div class="vip-resume-card resume-card" data-id="${id}"><h3>${name}</h3><span>${phone}</span></div>
    <div class="standard-resume-wrapper" data-id="${id}"><div class="standard-resume">
      <h2>${name}</h2><section><h3>工作經歷</h3><p>${name} Corp</p></section></div></div>
  </div>`;

  const w1 = build(mk('A', 'ANON-A', '0933333333'));
  const r1 = w1.TN104.capture104Resume();
  const w2 = build(mk('D', 'ANON-D', '0944444444'));
  const r2 = w2.TN104.capture104Resume();

  ok('run1 = A only', r1.html.includes('ANON-A') && !r1.html.includes('ANON-D'));
  ok('run2 = D only', r2.html.includes('ANON-D') && !r2.html.includes('ANON-A'));
  ok('run2 has no run1 phone', !r2.html.includes('0933333333'));
  ok('captures are independent', r1.html !== r2.html);
}

console.log('\n----------------------------------------');
console.log(`  ${pass} passed, ${fail} failed`);
console.log('----------------------------------------\n');
process.exit(fail ? 1 : 0);
