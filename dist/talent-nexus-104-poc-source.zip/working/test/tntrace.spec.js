/*
 * Behaviour-neutrality proof for the TNTRACE content tracer.
 * Asserts the wrappers forward arguments untouched, preserve return values,
 * fire the expected log lines, and leak no PII.
 * Run: node test/tntrace.spec.js
 */
const fs = require('fs');
const path = require('path');
const { JSDOM } = require('jsdom');

let pass = 0, fail = 0;
const ok = (n, c, x) => { c ? (pass++, console.log('  PASS  ' + n))
  : (fail++, console.log('  FAIL  ' + n + (x ? ' :: ' + x : ''))); };

const TRACER = fs.readFileSync(
  path.join(__dirname, '..', 'js', 'versions', 'v1', 'sites', 'tntrace.js'), 'utf8');

// Minimal stand-in for the real utils.message surface.
function makeEnv() {
  const dom = new JSDOM('<body></body>', { runScripts: 'outside-only' });
  const w = dom.window;
  const seen = { sent: [], registered: [] };
  const logs = [];
  w.eval(`var utils = { message: {
    sendMsg: function (m, cb) { globalThis.__sent.push(m); return 'SENDMSG_RV'; },
    register: function () {
      for (var i = 0; i < arguments.length; i++) globalThis.__reg.push(arguments[i]);
      return 'REGISTER_RV';
    }
  } };`);
  w.__sent = seen.sent;
  w.__reg = seen.registered;
  w.console.log = (...a) => logs.push(a.join(' '));
  w.eval(TRACER);
  return { w, seen, logs };
}

console.log('\n== tracer loads and announces itself ==');
{
  const { logs } = makeEnv();
  ok('logs activation', logs.some(l => l.includes('tracer active (content)')));
  ok('all lines prefixed [TNTRACE]', logs.every(l => l.startsWith('[TNTRACE]')));
}

console.log('\n== sendMsg is behaviour-neutral ==');
{
  const { w, seen } = makeEnv();
  const msg = { type: 'request.api.addResume.normal', settings: { data: { data: 'X' } } };
  const rv = w.utils.message.sendMsg(msg, 'CB');
  ok('return value preserved', rv === 'SENDMSG_RV', String(rv));
  ok('original message object forwarded by reference', seen.sent[0] === msg);
  ok('message not mutated', JSON.stringify(seen.sent[0]) ===
     JSON.stringify({ type: 'request.api.addResume.normal', settings: { data: { data: 'X' } } }));
  ok('exactly one send (no duplicate/suppressed call)', seen.sent.length === 1);
}

console.log('\n== register is behaviour-neutral ==');
{
  const { w, seen } = makeEnv();
  let innerArgs = null, innerThis = null;
  const listener = { type: 'request.api.loadStatus',
    callback: function (...a) { innerArgs = a; innerThis = this; return 'INNER_RV'; } };
  const rv = w.utils.message.register(listener);
  ok('return value preserved', rv === 'REGISTER_RV');
  ok('listener forwarded', seen.registered.length === 1);
  const msg = { type: 'request.api.loadStatus', response: [1, 2, 3] };
  const out = seen.registered[0].callback.call({ ctx: 1 }, msg, 'sender', 'sendResponse');
  ok('inner callback return preserved', out === 'INNER_RV');
  ok('inner callback receives all args', innerArgs.length === 3 && innerArgs[0] === msg);
  ok('inner callback `this` preserved', innerThis && innerThis.ctx === 1);
}

console.log('\n== CHAIN B trace lines ==');
{
  const { w, seen, logs } = makeEnv();
  w.utils.message.sendMsg({ type: 'request.api.loadJobs' });
  ok('gate marker logged once', logs.filter(l => l.includes('add_resume gate entered')).length === 1);
  w.utils.message.sendMsg({ type: 'request.api.loadJobs' });
  ok('gate marker not repeated', logs.filter(l => l.includes('add_resume gate entered')).length === 1);
  w.utils.message.sendMsg({ type: 'request.api.loadStatus' });
  ok('loadStatus sent logged', logs.some(l => l.includes('loadStatus sent')));

  w.utils.message.register({ type: 'request.api.loadStatus', callback: () => {} });
  seen.registered.at(-1).callback({ type: 'request.api.loadStatus', response: [1, 2, 3, 4] });
  ok('loadStatus response logged', logs.some(l => l.includes('loadStatus response received')));
  ok('status option count = 4', logs.some(l => l.includes('status option count: 4')));

  w.utils.message.register({ type: 'request.api.loadStatus', callback: () => {} });
  seen.registered.at(-1).callback({ type: 'request.api.loadStatus', response: null });
  ok('empty status -> count -1', logs.some(l => l.includes('status option count: -1')));
}

console.log('\n== CHAIN A trace lines ==');
{
  const { w, seen, logs } = makeEnv();
  w.utils.message.register({ type: 'request.api.addResume.normal', callback: () => {} });
  const cb = seen.registered.at(-1).callback;

  cb({ type: 'request.api.addResume.normal', response: { data: 'x'.repeat(45) } });
  ok('callback received logged', logs.some(l => l.includes('addResume.normal callback received')));
  ok('data type string', logs.some(l => l === '[TNTRACE] response.data type: string'));
  ok('data length 45', logs.some(l => l.includes('response.data length: 45')));
  ok('addFileName resolved true', logs.some(l => l.includes('addFileName resolved: true')));

  const l2 = [];
  w.console.log = (...a) => l2.push(a.join(' '));
  cb({ type: 'request.api.addResume.normal', response: { data: { oops: 1 } } });
  ok('non-string data flagged', l2.some(l => l.includes('non-string (object)')));
  ok('addFileName resolved false', l2.some(l => l.includes('addFileName resolved: false')));

  const l3 = [];
  w.console.log = (...a) => l3.push(a.join(' '));
  cb({ type: 'request.api.addResume.normal', response: { data: 'short' } });
  ok('short string -> not resolved', l3.some(l => l.includes('addFileName resolved: false')));
}

console.log('\n== getAddInfo / Save ==');
{
  const { w, seen, logs } = makeEnv();
  w.utils.message.sendMsg({ type: 'request.api.getAddInfo',
    settings: { data: { filename: 'SECRET_FILE_NAME' } } });
  ok('getAddInfo sent logged', logs.some(l => l.includes('getAddInfo sent')));
  ok('filenameAttached=true', logs.some(l => l.includes('filenameAttached=true')));
  ok('filename VALUE never logged', !logs.some(l => l.includes('SECRET_FILE_NAME')));

  w.utils.message.register({ type: 'request.api.getAddInfo', callback: () => {} });
  const cb = seen.registered.at(-1).callback;
  cb({ type: 'request.api.getAddInfo', response: [{ extract: { chineseName: 'PII' } }] });
  ok('getAddInfo usable true', logs.some(l => l.includes('getAddInfo usable data: true')));
  ok('extract contents never logged', !logs.some(l => l.includes('PII')));

  const l2 = [];
  w.console.log = (...a) => l2.push(a.join(' '));
  cb({ type: 'request.api.getAddInfo', response: [] });
  ok('empty response -> usable false', l2.some(l => l.includes('getAddInfo usable data: false')));

  const l3 = [];
  w.console.log = (...a) => l3.push(a.join(' '));
  w.utils.message.sendMsg({ type: 'request.api.submit',
    settings: { data: 'data=%7B%22chineseName%22%3A%22PII%22%7D' } });
  ok('Save click logged', l3.some(l => l.includes('Save click fired')));
  ok('addbyplug logged', l3.some(l => l.includes('addbyplug sent')));
  ok('submit payload never logged', !l3.some(l => l.includes('PII')));
}

console.log('\n== tracer never throws into the host ==');
{
  const { w, seen } = makeEnv();
  let ran = false;
  w.utils.message.register({ type: 'request.api.addResume.normal',
    callback: () => { ran = true; } });
  const cb = seen.registered.at(-1).callback;
  let threw = false;
  try { cb(undefined); } catch (e) { threw = true; }
  ok('malformed message does not throw', !threw);
  ok('inner callback still invoked', ran);

  let threw2 = false;
  try { w.utils.message.sendMsg({}); } catch (e) { threw2 = true; }
  ok('typeless sendMsg does not throw', !threw2);
  ok('typeless message still forwarded', seen.sent.length === 1);
}

console.log('\n== double-load guard ==');
{
  const { w, logs } = makeEnv();
  const before = w.utils.message.sendMsg;
  w.eval(TRACER);
  ok('second load does not re-wrap', w.utils.message.sendMsg === before);
  ok('activation logged once', logs.filter(l => l.includes('tracer active')).length === 1);
}

console.log('\n== no PII vocabulary in tracer CODE (AST-based) ==');
{
  // Raw-text scanning gave false failures: the banned words appear in the
  // privacy header comment. Regex comment-stripping is also wrong (it breaks
  // on "/*" inside string literals), so use a real parser: collect comments
  // via acorn's onComment hook and blank out exactly those source ranges.
  const acorn = require('acorn');
  const comments = [];
  acorn.parse(TRACER, {
    ecmaVersion: 2020, sourceType: 'script', onComment: comments
  });
  ok('parses as valid ES script', true);
  ok('found the header comment(s)', comments.length > 0);

  let code = TRACER;
  // Blank comment ranges back-to-front so earlier offsets stay valid.
  comments.sort((a, b) => b.start - a.start).forEach(c => {
    code = code.slice(0, c.start) +
           ' '.repeat(c.end - c.start) +
           code.slice(c.end);
  });

  ok('comment text removed', !code.includes('PRIVACY'));
  ok('executable code retained',
     code.includes('utils.message.sendMsg') && code.length === TRACER.length);

  const banned = ['chineseName', 'mobile', 'email', 'outerHTML', 'loginparam',
                  'cookie', 'token', 'uuidname', 'Config.api'];
  banned.forEach(b => ok('code never references ' + b, !code.includes(b)));
  ok('never logs a response body', !/log\([^)]*\bresp\b\s*\)/.test(code));

  // Independent AST check: every string literal the tracer can emit must be
  // a static label — no template/concat pulling values out of the payload.
  const banned2 = ['chineseName', 'mobile', 'email', 'uuidname', 'loginparam'];
  let leak = null;
  const walk = n => {
    if (!n || typeof n !== 'object') return;
    if (n.type === 'Literal' && typeof n.value === 'string' &&
        banned2.some(b => n.value.includes(b))) leak = n.value;
    for (const k in n) {
      if (k === 'start' || k === 'end') continue;
      const v = n[k];
      Array.isArray(v) ? v.forEach(walk) : walk(v);
    }
  };
  walk(acorn.parse(TRACER, { ecmaVersion: 2020, sourceType: 'script' }));
  ok('no PII field name in any string literal', leak === null, String(leak));
}

console.log('\n----------------------------------------');
console.log(`  ${pass} passed, ${fail} failed`);
console.log('----------------------------------------\n');
process.exit(fail ? 1 : 0);
